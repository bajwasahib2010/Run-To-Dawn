Drop PNGs here with these EXACT names and the game uses them automatically.
Missing files = colored boxes, so you can add art one piece at a time.
Draw them facing RIGHT, transparent background. Height is fixed by the game,
width follows your image, so match these aspect ratios:

elias.png, victor.png, lucian.png   narrow, about 36 wide : 70 tall
pursuer.png                         about 110 : 130  (the thing chasing you)
crate.png                           about 50 : 50
barrier.png                         about 110 : 45   (wide and low)
wall.png                            about 60 : 95    (tall)
bouncepad.png                       about 80 : 18
chapel.png                          about 260 : 300  (end of every level)
ground.png                          a tileable square, repeats along the floor
bg_level1.png ... bg_level4.png     1280x720 or bigger, one per level
title.png is not used yet.
