extends CanvasLayer
# Volume options: MASTER / MUSIC / SOUND EFFECTS in 10% steps.
# Used by the main menu and the pause menu: create it, add_child it, call open().
# The settings are remembered between sessions (see Audio.gd).

const UIKit = preload('res://Scripts/UIKit.gd')
const ROWS = [['MASTER VOLUME', 'master'], ['MUSIC', 'music'], ['SOUND EFFECTS', 'sfx']]
const STEPS = 10

var segs = {}
var pct = {}
var done_btn
var on_close = null

func _init():
    layer = 60
    process_mode = Node.PROCESS_MODE_ALWAYS     # keep working while the game is paused

func _ready():
    visible = false
    var dim = ColorRect.new()
    dim.color = Color(0, 0, 0, 0.88)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    add_child(UIKit.make_label('OPTIONS', 72, UIKit.GOLD, Vector2(0, 50), 1280))
    var y = 210.0
    for row in ROWS:
        var key = row[1]
        add_child(UIKit.make_label(row[0], 30, UIKit.CREAM, Vector2(90, y + 8), 360, HORIZONTAL_ALIGNMENT_LEFT))
        var minus = UIKit.make_button('-', 38, Vector2(470, y), Vector2(64, 60))
        minus.pressed.connect(_step.bind(key, -1))
        add_child(minus)
        segs[key] = []
        for i in range(STEPS):
            var seg = ColorRect.new()
            seg.position = Vector2(550 + i * 38, y + 4)
            seg.size = Vector2(34, 52)
            seg.mouse_filter = Control.MOUSE_FILTER_STOP
            seg.gui_input.connect(_seg_input.bind(key, i))
            add_child(seg)
            segs[key].append(seg)
        var plus = UIKit.make_button('+', 38, Vector2(940, y), Vector2(64, 60))
        plus.pressed.connect(_step.bind(key, 1))
        add_child(plus)
        pct[key] = UIKit.make_label('', 30, UIKit.GOLD, Vector2(1020, y + 8), 150, HORIZONTAL_ALIGNMENT_LEFT)
        add_child(pct[key])
        y += 100.0
    add_child(UIKit.make_label('Click a bar, or use - and +.   Press M in the game to mute everything.', 20, UIKit.CREAM, Vector2(0, 530), 1280))
    done_btn = UIKit.make_button('DONE', 32, Vector2(430, 590), Vector2(420, 66))
    done_btn.pressed.connect(close)
    add_child(done_btn)
    _refresh()

func _seg_input(event, key, i):
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        var cur = int(round(Audio.get_volume(key) * STEPS))
        _set_steps(key, i if cur == i + 1 else i + 1)      # click the last lit bar again to turn it down

func _step(key, d):
    var cur = int(round(Audio.get_volume(key) * STEPS))
    _set_steps(key, cur + d)

func _set_steps(key, n):
    n = clampi(n, 0, STEPS)
    Audio.set_volume(key, float(n) / STEPS)
    if key == 'sfx':
        Audio.sfx('hit', -4.0)          # so you can hear how loud the effects are
    elif key == 'master':
        Audio.sfx('select')
    _refresh()

func _refresh():
    for key in segs.keys():
        var n = int(round(Audio.get_volume(key) * STEPS))
        for i in range(STEPS):
            segs[key][i].color = UIKit.GOLD if i < n else Color(0.2, 0.2, 0.25)
        pct[key].text = '%d%%' % (n * 10)

func open():
    _refresh()
    visible = true
    done_btn.grab_focus()

func close():
    visible = false
    get_viewport().gui_release_focus()
    Audio.save_settings()
    if on_close != null:
        on_close.call()

func _input(event):
    if visible and event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE:
            close()
            get_viewport().set_input_as_handled()
