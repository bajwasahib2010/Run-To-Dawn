extends Control
# Scrolling end credits, drawn in code. Any key / click / tap skips.
# Load it from your ending with:
#     get_tree().change_scene_to_file("res://Scenes/Credits.tscn")

@export var next_scene: String = "res://Scenes/Ending.tscn"

const W := 1280.0
const H := 720.0
const SPEED := 70.0

# [text, size, color]
var lines: Array = []
var y_start := H
var total_h := 0.0
var t := 0.0
var done := false
var stars: Array = []
var font: Font

# ---- music (synthesised in code, no sound files needed) ----
const RATE := 11025
var music: AudioStreamPlayer


func _ready() -> void:
	font = ThemeDB.fallback_font
	Audio.stop_music()      # the credits have their own music
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var gold = Color(1.0, 0.82, 0.25)
	var white = Color(0.95, 0.95, 0.95)
	lines = [
		["MAXIMUS LARPUS", 84, Color(0.9, 0.15, 0.12)], ["", 40, white],
		["CODING", 44, gold], ["M. Safiullah", 36, white], ["Zaid Ali Bajwa", 36, white], ["", 40, white],
		["DESIGNING", 44, gold], ["Zaid Ali Bajwa", 36, white], ["Zulkifal Khan", 36, white], ["", 40, white],
		["PUBLISHING", 44, gold], ["Zaid Ali Bajwa", 36, white], ["", 80, white],
		["THANKS FOR PLAYING", 40, gold]
	]
	for l in lines:
		total_h += l[1] * 1.7
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	for i in 80:
		stars.append(Vector3(rng.randf() * W, rng.randf() * H, rng.randf() * 6.0))
	music = AudioStreamPlayer.new()
	music.stream = _make_music()
	music.volume_db = -40.0
	add_child(music)
	music.play()


func _process(delta: float) -> void:
	var dt = minf(delta, 0.1)   # generating the music can cause one long first frame
	t += dt
	# fade the music in at the start and out as the credits finish
	var end_t = (H + total_h) / SPEED
	var target = -9.0
	if end_t - t < 2.0:
		target = -50.0
	music.volume_db = lerpf(music.volume_db, target, minf(dt * 1.5, 1.0))
	if y_start + total_h < 0.0:
		_finish()
	y_start = H - t * SPEED
	queue_redraw()


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		_finish()
	elif event is InputEventMouseButton and event.pressed:
		_finish()
	elif event is InputEventScreenTouch and event.pressed:
		_finish()


func _finish() -> void:
	if done:
		return
	done = true 
	get_tree().change_scene_to_file("res://Scenes/MainMenu.tscn")


func _draw() -> void:
	draw_rect(Rect2(0, 0, W, H), Color(0.03, 0.02, 0.07))
	for s in stars:
		var a = 0.3 + 0.5 * (0.5 + 0.5 * sin(t * 2.0 + s.z * 3.0))
		draw_rect(Rect2(s.x, s.y, 4, 4), Color(1, 1, 0.9, a))
	draw_rect(Rect2(0, H - 70, W, 70), Color(0.07, 0.04, 0.09))
	var y = y_start
	for l in lines:
		y += l[1] * 1.7
		if l[0] == "":
			continue
		var w = font.get_string_size(l[0], HORIZONTAL_ALIGNMENT_LEFT, -1, l[1]).x
		var x = (W - w) * 0.5
		draw_string(font, Vector2(x + 4, y + 4), l[0], HORIZONTAL_ALIGNMENT_LEFT, -1, l[1], Color(0, 0, 0, 0.8))
		draw_string(font, Vector2(x, y), l[0], HORIZONTAL_ALIGNMENT_LEFT, -1, l[1], l[2])


# Slow, hopeful loop: soft chords + bass + a gentle plucked arpeggio. 12 s, loops.
func _make_music() -> AudioStreamWAV:
	var chords = [
		[220.00, 261.63, 329.63, 110.00],   # Am
		[174.61, 220.00, 261.63, 87.31],    # F
		[261.63, 329.63, 392.00, 130.81],   # C
		[196.00, 246.94, 293.66, 98.00]     # G
	]
	var slot = 3.0
	var step = 0.375
	var n = int(slot * 4.0 * RATE)
	var data := PackedFloat32Array()
	data.resize(n)
	for i in n:
		var tt = float(i) / RATE
		var ci = int(tt / slot)
		var ch = chords[ci]
		var u = (tt - ci * slot) / slot
		var env = clampf(u * 6.0, 0.0, 1.0) * clampf((1.0 - u) * 6.0, 0.0, 1.0)
		var pad = (sin(TAU * ch[0] * tt) + sin(TAU * ch[1] * tt) + sin(TAU * ch[2] * tt)) * 0.07
		pad += sin(TAU * ch[3] * tt) * 0.16
		pad *= env * (0.8 + 0.2 * sin(TAU * 0.25 * tt))
		# arpeggio pluck
		var k = int(tt / step)
		var local = tt - k * step
		var order = [0, 1, 2, 1, 2, 1, 0, 1]
		var f = ch[order[k % 8]] * 2.0
		var pluck = (sin(TAU * f * local) + 0.3 * sin(TAU * f * 2.0 * local)) * exp(-local * 9.0) * minf(local * 300.0, 1.0) * 0.12
		data[i] = pad + pluck
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	for i in n:
		bytes.encode_s16(i * 2, int(clampf(data[i], -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = bytes
	w.loop_mode = AudioStreamWAV.LOOP_FORWARD
	w.loop_begin = 0
	w.loop_end = n
	return w
