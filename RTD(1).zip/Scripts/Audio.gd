extends Node

# Sound manager (autoload name: Audio). Everything is optional: a missing file is just skipped.
#   Audio.play_music('level1', true)  -> loops res://Audio/music_level1.ogg (+ music_level1_chase.ogg)
#   Audio.set_chase(0.0 to 1.0)       -> how loud the hellhound "chase" layer is
#   Audio.sfx('jump')                 -> plays res://Audio/sfx_jump.wav
#   Audio.duck(seconds)               -> briefly lowers the music (for stings)
# Press M anywhere to mute / unmute.

const MUSIC_DB = -9.0     # music volume (lower number = quieter)
const SFX_DB = 0.0        # sound-effect volume
const POOL = 10           # how many sounds can play at once

var music
var chase
var players = []
var cache = {}
var next_player = 0
var current = ''
var chase_on = false
var chase_amount = 0.0
var duck_timer = 0.0
var stopping = false
var muted = false

# ---- volume settings (Options screen): each 0.0 to 1.0, remembered between sessions ----
const SETTINGS_PATH = 'user://run_to_dawn_settings.cfg'
var vol = {'master': 1.0, 'music': 1.0, 'sfx': 1.0}

func _ready():
    process_mode = Node.PROCESS_MODE_ALWAYS
    music = AudioStreamPlayer.new()
    add_child(music)
    chase = AudioStreamPlayer.new()
    add_child(chase)
    chase.volume_db = -80.0
    for i in range(POOL):
        var p = AudioStreamPlayer.new()
        add_child(p)
        players.append(p)
    load_settings()

func _load_stream(path):
    if not ResourceLoader.exists(path):
        return null
    var s = load(path)
    if s != null and 'loop' in s:
        s.loop = true
    return s

# Start a looping track. Calling it again with the same name keeps it playing
# (so the music does not restart every time you retry a level).
func play_music(track, with_chase = false):
    chase_on = with_chase
    stopping = false
    if track == current and music.playing:
        return
    current = track
    var s = _load_stream('res://Audio/music_' + track + '.ogg')
    chase.stop()
    if s == null:
        music.stop()
        return
    music.stream = s
    music.volume_db = -40.0
    music.play()
    if with_chase:
        var cs = _load_stream('res://Audio/music_' + track + '_chase.ogg')
        if cs != null:
            chase.stream = cs
            chase.volume_db = -80.0
            chase.play()

func stop_music():
    stopping = true

# 0 = hellhound is far away, 1 = it is on your heels
func set_chase(amount):
    chase_amount = clamp(amount, 0.0, 1.0)

func duck(seconds):
    duck_timer = seconds

func sfx(sound, vol_db = 0.0, pitch = 1.0):
    if vol['sfx'] <= 0.001:
        return
    if not cache.has(sound):
        var path = 'res://Audio/sfx_' + sound + '.wav'
        cache[sound] = load(path) if ResourceLoader.exists(path) else null
    var s = cache[sound]
    if s == null:
        return
    var p = players[next_player]
    next_player = (next_player + 1) % players.size()
    p.stream = s
    p.volume_db = SFX_DB + vol_db + _db(vol['sfx'])
    p.pitch_scale = pitch
    p.play()

func _process(delta):
    duck_timer = max(duck_timer - delta, 0.0)
    var m_target = MUSIC_DB + _db(vol['music']) - 3.0 * chase_amount
    if duck_timer > 0.0:
        m_target -= 14.0
    if stopping:
        m_target = -60.0
    music.volume_db = move_toward(music.volume_db, max(m_target, -80.0), 30.0 * delta)
    var c_target = -80.0
    if chase_on and not stopping and chase_amount > 0.03:
        c_target = lerp(-30.0, MUSIC_DB + 3.0, pow(chase_amount, 1.2)) + _db(vol['music'])
    chase.volume_db = move_toward(chase.volume_db, max(c_target, -80.0), 45.0 * delta)
    if stopping and music.volume_db <= -55.0:
        music.stop()
        chase.stop()
        stopping = false
        current = ''

func _unhandled_input(event):
    if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_M:
        muted = not muted
        AudioServer.set_bus_mute(AudioServer.get_bus_index('Master'), muted)

# ---------------------------------------------------------------- volume settings
func _db(v):
    return -80.0 if v <= 0.001 else linear_to_db(v)

func get_volume(key):
    return vol[key]

func set_volume(key, v):
    vol[key] = clamp(v, 0.0, 1.0)
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index('Master'), _db(vol['master']))

func save_settings():
    var cf = ConfigFile.new()
    for k in vol.keys():
        cf.set_value('audio', k, vol[k])
    cf.save(SETTINGS_PATH)

func load_settings():
    var cf = ConfigFile.new()
    if cf.load(SETTINGS_PATH) == OK:
        for k in vol.keys():
            vol[k] = clamp(float(cf.get_value('audio', k, 1.0)), 0.0, 1.0)
    set_volume('master', vol['master'])
