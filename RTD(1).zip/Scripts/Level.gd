extends Node2D

# ONE scene plays EVERY level. It reads GameData.levels[GameData.level_index]
# and builds the track in code. To change levels, edit the table in GameData.gd.

const Art = preload('res://Scripts/Art.gd')
const PlayerScript = preload('res://Scripts/Player.gd')
const PauseScript = preload('res://Scripts/Pause.gd')
const UIKit = preload('res://Scripts/UIKit.gd')
const ObstacleScript = preload('res://Scripts/Obstacle.gd')
const MonsterScript = preload('res://Scripts/MonsterArt.gd')

const GROUND_Y = 560.0
const START_X = 400.0

var cfg
var player
var chasers = []            # every monster hunting you this level (see _build_pursuer)
var finish_x = 0.0
var state = 'ready'     # ready -> running -> caught / won
var time = 0.0
var growl_timer = 0.0

# ---- bounce-back / hearts ----
const KNOCKBACK = 150.0      # px you are thrown back toward the hellhound
const INVULN_TIME = 1.0      # seconds you can't be hit again
var max_hearts = 3
var hearts = 3
var hits = 0
var cheated = false          # runs with cheats are not saved
var pause_menu = null
var cheat_label = null
var invuln = 0.0
var knock_left = 0.0
var heart_pixels = []

# ---- FREE PLAY (endless: no chapel, no finish line, the run only ends when you die) ----
const FREE_STAGES = [[6000.0, 'vampire'], [12000.0, 'werewolf'], [20000.0, 'wraith'], [30000.0, 'demon']]
var endless = false
var free_label = null
var free_obs = []
var free_deco = []
var free_obs_rng = RandomNumberGenerator.new()
var free_deco_rng = RandomNumberGenerator.new()
var free_next_obs = 1300.0
var free_next_deco = -200.0
var free_tick = 0.0
var free_stage = 0
var free_heal_mark = 0

var time_label
var progress_fill
var gap_fill
var banner

func _ready():
    endless = GameData.free_play
    cfg = GameData.level_cfg(GameData.level_index)      # level table + chosen difficulty
    if endless:
        _free_setup_cfg()
    max_hearts = GameData.difficulty_data()['hearts']
    hearts = max_hearts
    cheated = GameData.any_cheat()
    finish_x = cfg['length']
    _build_background()
    _build_ground()
    if endless:
        _free_init()
    else:
        _build_decor()
        _build_obstacles()
        _build_chapel()
    _build_player()
    _build_pursuer()
    _build_hud()
    Audio.set_chase(0.0)
    Audio.play_music(cfg['music'], true)
    _start_sequence()

# ---------------------------------------------------------------- building

func _poly(points, color):
    var p = Polygon2D.new()
    p.polygon = PackedVector2Array(points)
    p.color = color
    return p

func _rect_poly(x, y, w, h, color):
    return _poly([Vector2(x, y), Vector2(x + w, y), Vector2(x + w, y + h), Vector2(x, y + h)], color)

func _build_background():
    var layer = CanvasLayer.new()
    layer.layer = -10
    add_child(layer)
    var sky = ColorRect.new()
    sky.color = cfg['sky']
    layer.add_child(sky)
    sky.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    # pixel-art parallax set: Sprites/bg_level1_sky.png, _far.png, _mid.png, _fog.png
    var base = 'res://Sprites/bg_level%d' % (GameData.level_index + 1)
    if ResourceLoader.exists(base + '_sky.png'):
        _build_parallax(base)
        return
    # optional picture: Sprites/bg_level1.png, bg_level2.png ...
    var path = 'res://Sprites/bg_level%d.png' % (GameData.level_index + 1)
    if ResourceLoader.exists(path):
        var pic = TextureRect.new()
        pic.texture = load(path)
        pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
        layer.add_child(pic)
        pic.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _build_parallax(base):
    # layers scroll at different speeds as the camera runs: sky stays put, far hills
    # drift slowly, nearer buildings/trees faster, fog fastest. Art is 640x360, drawn at 2x.
    var pb = ParallaxBackground.new()
    pb.layer = -9
    add_child(pb)
    var parts = [['_sky', 0.0], ['_far', 0.10], ['_mid', 0.30], ['_fog', 0.55]]
    for part in parts:
        var path = base + part[0] + '.png'
        if not ResourceLoader.exists(path):
            continue
        var pl = ParallaxLayer.new()
        pl.motion_scale = Vector2(part[1], 0.0)
        if part[1] > 0.0:
            pl.motion_mirroring = Vector2(1280.0, 0.0)
        pb.add_child(pl)
        var s = Sprite2D.new()
        s.texture = load(path)
        s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
        s.centered = false
        s.scale = Vector2(2.0, 2.0)
        pl.add_child(s)

func _build_ground():
    var total = cfg['length'] + 4000.0
    var body = StaticBody2D.new()
    body.position = Vector2(-2000.0, GROUND_Y)
    add_child(body)
    var shape = CollisionShape2D.new()
    var rect = RectangleShape2D.new()
    rect.size = Vector2(total, 200.0)
    shape.shape = rect
    shape.position = Vector2(total * 0.5, 100.0)
    body.add_child(shape)

    # look: Sprites/ground_level1.png ... (tiled), else Sprites/ground.png, else a plain color
    var gpath = 'res://Sprites/ground_level%d.png' % (GameData.level_index + 1)
    if not ResourceLoader.exists(gpath):
        gpath = 'res://Sprites/ground.png'
    if ResourceLoader.exists(gpath):
        var tiles = TextureRect.new()
        tiles.texture = load(gpath)
        tiles.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
        tiles.stretch_mode = TextureRect.STRETCH_TILE
        tiles.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        tiles.size = Vector2(total, 400.0)
        body.add_child(tiles)
    else:
        var floor_rect = ColorRect.new()
        floor_rect.color = cfg['ground']
        floor_rect.size = Vector2(total, 400.0)
        body.add_child(floor_rect)
        var edge = ColorRect.new()
        edge.color = cfg['ground'].lightened(0.3)
        edge.size = Vector2(total, 6.0)
        body.add_child(edge)

func _build_decor():
    var rng = RandomNumberGenerator.new()
    rng.seed = 500 + GameData.level_index
    var x = -200.0
    while x < cfg['length'] + 1500.0:
        var d = _make_deco(rng)
        d.position = Vector2(x, GROUND_Y)
        d.z_index = -5
        add_child(d)
        x += rng.randf_range(140.0, 380.0)

func _make_deco(rng):
    var holder = Node2D.new()
    var col = cfg['deco_color']
    var kind = cfg['deco']
    var h = rng.randf_range(120.0, 260.0)
    # pixel-art scenery: Sprites/deco_<kind>_0.png and deco_<kind>_1.png (drawn at 2x)
    var variant = rng.randi() % 2
    var sname = 'deco_%s_%d' % [kind, variant]
    if ResourceLoader.exists('res://Sprites/' + sname + '.png'):
        var tex = load('res://Sprites/' + sname + '.png')
        holder.add_child(Art.visual(sname, Vector2(0, tex.get_height() * 2.0), col))
        return holder
    if kind == 'tree':
        holder.add_child(_poly([Vector2(-55, 0), Vector2(0, -h), Vector2(55, 0)], col))
    elif kind == 'house':
        holder.add_child(_rect_poly(-60, -h * 0.55, 120, h * 0.55, col))
        holder.add_child(_poly([Vector2(-75, -h * 0.55), Vector2(0, -h * 0.85), Vector2(75, -h * 0.55)], col.lightened(0.1)))
    elif kind == 'pillar':
        holder.add_child(_rect_poly(-28, -h * 1.3, 56, h * 1.3, col))
    elif kind == 'gravestone':
        holder.add_child(_rect_poly(-30, -h * 0.5, 60, h * 0.5, col))
        holder.add_child(_rect_poly(-22, -h * 0.5 - 16, 44, 16, col))
        holder.add_child(_rect_poly(-6, -h * 0.5 - 34, 12, 34, col.lightened(0.1)))
    elif kind == 'spire':
        holder.add_child(_poly([Vector2(-40, 0), Vector2(0, -h * 1.5), Vector2(40, 0)], col))
        holder.add_child(_poly([Vector2(10, 0), Vector2(50, -h * 0.9), Vector2(90, 0)], col.lightened(0.08)))
    else:
        holder.add_child(_rect_poly(-5, -110, 10, 110, col))
        holder.add_child(_rect_poly(-30, -110, 60, 8, col))
    return holder

func _build_obstacles():
    var rng = RandomNumberGenerator.new()
    rng.seed = 1000 + GameData.level_index      # same layout every retry
    var x = 1300.0
    var last = finish_x - 700.0
    while x < last:
        var o = ObstacleScript.new()
        if rng.randf() < cfg['pad_chance']:
            o.is_pad = true
            o.size = Vector2(80, 18)
            o.color = Color(1.0, 0.85, 0.2)
            o.sprite_name = 'bouncepad'
        else:
            var types = cfg['types']
            var kind = types[rng.randi() % types.size()]
            o.color = cfg['obstacle_color']
            if kind == 'crate':
                o.size = Vector2(50, 50)
                o.sprite_name = 'crate'
            elif kind == 'wide':
                o.size = Vector2(110, 44)
                o.sprite_name = 'barrier'
            else:
                o.size = Vector2(60, 96)
                o.sprite_name = 'wall'
        o.position = Vector2(x, GROUND_Y)
        o.z_index = 1
        add_child(o)
        x += rng.randf_range(cfg['spacing_min'], cfg['spacing_max'])
        if o.is_pad:
            x += 450.0      # a bounce flies far, so leave landing room

func _build_chapel():
    var holder = Node2D.new()
    holder.position = Vector2(finish_x + 120.0, GROUND_Y)
    holder.z_index = -1
    add_child(holder)
    if ResourceLoader.exists('res://Sprites/chapel.png'):
        holder.add_child(Art.visual('chapel', Vector2(260, 300), Color.WHITE))
    else:
        holder.add_child(_rect_poly(-100, -180, 200, 180, Color(0.75, 0.65, 0.5)))
        holder.add_child(_poly([Vector2(-125, -180), Vector2(0, -310), Vector2(125, -180)], Color(0.35, 0.2, 0.15)))
        holder.add_child(_rect_poly(-28, -95, 56, 95, Color(1.0, 0.85, 0.4)))

func _build_player():
    player = PlayerScript.new()
    player.position = Vector2(START_X, GROUND_Y)
    player.z_index = 2
    add_child(player)

func _build_pursuer():
    chasers = []
    var roster = cfg['monsters']
    for i in range(roster.size()):
        _add_chaser(roster[i], START_X - cfg['gap'] - 170.0 * i)    # extra monsters start further back

func _add_chaser(kind, start_x):
    var st = GameData.chaser_stats(kind, GameData.level_index, _free_power())
    var node = Node2D.new()
    node.position = Vector2(start_x, GROUND_Y)
    node.z_index = 2
    add_child(node)
    # a PNG strip Sprites/pursuer_<kind>.png (64x48 per frame, 6 frames) is used if it exists
    # (pursuer.png still works for the hellhound); otherwise the monster is drawn in code
    var look = Art.animated('pursuer_' + kind, Vector2(64, 48), {'run': [0, 1, 2, 3, 4, 5]}, 2.0, 13.0)
    if look == null and kind == 'hellhound':
        look = Art.animated('pursuer', Vector2(64, 48), {'run': [0, 1, 2, 3, 4, 5]}, 2.0, 13.0)
    var art = null
    if look != null:
        node.add_child(look)
    else:
        art = MonsterScript.new()
        art.kind = kind
        node.add_child(art)
    chasers.append({'node': node, 'art': art, 'kind': kind, 'st': st, 'state': 'run',
            'timer': _next_special(st, true), 'phase': randf() * 6.0})

# FREE PLAY: how strong monsters are right now (they grow stronger the further you run).
# Returns -1 outside endless play, which means "use the level's normal power".
func _free_power():
    if not endless or player == null:
        return -1.0
    return clamp((player.position.x - START_X) / 40000.0, 0.0, 1.0) * GameData.difficulty_data()['power']

# seconds until a monster's next lunge / blink
func _next_special(st, first):
    if st['interval'] <= 0.0:
        return 9999.0
    return (st['interval'] + (2.5 if first else 0.0)) * randf_range(0.8, 1.15)

func _front_x():
    var fx = -99999.0
    for c in chasers:
        fx = max(fx, c['node'].position.x)
    return fx

func _monster_names():
    var names = []
    for k in cfg['monsters']:
        names.append(GameData.monsters[k]['name'])
    return ' + '.join(names)

# moves every chaser and runs its special move (lunge / blink / frenzy)
func _update_chasers(delta):
    for c in chasers:
        var st = c['st']
        var node = c['node']
        var spd = player.char_speed * st['ratio']
        if st['frenzy'] > 0.0:
            spd *= 1.0 + st['frenzy'] * clamp(time / 40.0, 0.0, 1.0)
        c['timer'] -= delta
        var s = c['state']
        if s == 'run':
            if c['timer'] <= 0.0:
                c['state'] = 'warn'                      # telegraph: it flashes before it strikes
                c['timer'] = 0.6 if st['blink'] > 0.0 else 0.5
                Audio.sfx('growl', -6.0, randf_range(1.0, 1.25))
        elif s == 'warn':
            spd *= 0.85
            if c['timer'] <= 0.0:
                if st['blink'] > 0.0:
                    var target = player.position.x - 140.0
                    node.position.x = max(node.position.x, min(node.position.x + st['blink'], target))
                    c['state'] = 'run'
                    c['timer'] = _next_special(st, false)
                else:
                    c['state'] = 'dash'
                    c['timer'] = 0.7
        elif s == 'dash':
            spd *= st['dash_mult']
            if c['timer'] <= 0.0:
                c['state'] = 'recover'
                c['timer'] = 1.4
        elif s == 'recover':
            spd *= st['rec']
            if c['timer'] <= 0.0:
                c['state'] = 'run'
                c['timer'] = _next_special(st, false)
        node.position.x += spd * delta
        node.position.y = GROUND_Y - abs(sin(time * 12.0 + c['phase'])) * 4.0
        var art = c['art']
        if art != null:
            art.warn = (c['state'] == 'warn')
            art.dashing = (c['state'] == 'dash')
        elif c['state'] == 'warn':
            node.modulate = Color(1.6, 1.2, 1.2)
        else:
            node.modulate = Color.WHITE

func _build_hud():
    var hud = CanvasLayer.new()
    hud.layer = 10
    add_child(hud)

    time_label = Label.new()
    time_label.position = Vector2(30, 18)
    time_label.add_theme_font_size_override('font_size', 38)
    hud.add_child(time_label)

    var title = Label.new()
    title.text = cfg['title']
    title.position = Vector2(30, 68)
    title.add_theme_font_size_override('font_size', 20)
    hud.add_child(title)

    # distance bar (how far to the chapel)
    var bar1 = ColorRect.new()
    bar1.color = Color(0, 0, 0, 0.5)
    bar1.position = Vector2(340, 28)
    bar1.size = Vector2(600, 16)
    hud.add_child(bar1)
    progress_fill = ColorRect.new()
    progress_fill.color = Color(1.0, 0.9, 0.5)
    progress_fill.position = Vector2(340, 28)
    progress_fill.size = Vector2(0, 16)
    hud.add_child(progress_fill)

    # danger bar (how far ahead of the pursuer you are)
    var bar2 = ColorRect.new()
    bar2.color = Color(0, 0, 0, 0.5)
    bar2.position = Vector2(340, 52)
    bar2.size = Vector2(600, 10)
    hud.add_child(bar2)
    gap_fill = ColorRect.new()
    gap_fill.position = Vector2(340, 52)
    gap_fill.size = Vector2(600, 10)
    hud.add_child(gap_fill)

    banner = Label.new()
    banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    banner.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    banner.add_theme_font_size_override('font_size', 56)
    banner.add_theme_color_override('font_outline_color', Color.BLACK)
    banner.add_theme_constant_override('outline_size', 10)
    hud.add_child(banner)
    banner.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build_hearts(hud)
    if endless:
        free_label = UIKit.make_label('', 24, UIKit.CREAM, Vector2(340, 68), 600)
        hud.add_child(free_label)
    # difficulty tag, cheat tag and pause button
    hud.add_child(UIKit.make_label(GameData.difficulty.to_upper(), 18, UIKit.GOLD, Vector2(30, 136), 200, HORIZONTAL_ALIGNMENT_LEFT))
    cheat_label = UIKit.make_label('CHEATS ON - NOT SAVED', 18, UIKit.RED, Vector2(30, 160), 320, HORIZONTAL_ALIGNMENT_LEFT)
    cheat_label.visible = cheated
    hud.add_child(cheat_label)
    var pb = UIKit.make_button('II', 22, Vector2(1196, 16), Vector2(60, 48))
    pb.focus_mode = Control.FOCUS_NONE
    pb.pressed.connect(try_pause)
    hud.add_child(pb)
    pause_menu = PauseScript.new()
    pause_menu.level = self
    add_child(pause_menu)

func try_pause():
    if state == 'running' and pause_menu != null and not get_tree().paused:
        pause_menu.open()

func on_cheats_changed():
    if GameData.any_cheat():
        cheated = true
    player.refresh_stats()
    cheat_label.visible = cheated

func _build_hearts(hud):
    var shape = [' XX XX ', 'XXXXXXX', 'XXXXXXX', ' XXXXX ', '  XXX  ', '   X   ']
    for i in range(max_hearts):
        var pixels = []
        for r in range(shape.size()):
            for c in range(shape[r].length()):
                if shape[r][c] == 'X':
                    var px = ColorRect.new()
                    px.position = Vector2(30 + i * 40 + c * 4, 104 + r * 4)
                    px.size = Vector2(4, 4)
                    hud.add_child(px)
                    pixels.append(px)
        heart_pixels.append(pixels)
    _update_hearts()

func _update_hearts():
    for i in range(heart_pixels.size()):
        var col = Color(0.9, 0.1, 0.15) if i < hearts else Color(0.22, 0.22, 0.25)
        for px in heart_pixels[i]:
            px.color = col

# ---------------------------------------------------------------- flow

func _start_sequence():
    Audio.sfx('toll', -6.0)
    banner.add_theme_font_size_override('font_size', 42)
    banner.text = cfg['title'] + '\n' + cfg['story'] + '\n\nHUNTED BY:  ' + _monster_names()
    await get_tree().create_timer(2.6).timeout
    banner.add_theme_font_size_override('font_size', 56)
    banner.text = 'RUN!'
    Audio.sfx('go')
    Audio.sfx('howl', -4.0)
    state = 'running'
    player.active = true
    await get_tree().create_timer(0.7).timeout
    if state == 'running':
        banner.text = ''

func _physics_process(delta):
    if state != 'running':
        return
    time += delta
    _update_chasers(delta)
    if endless:
        _free_tick(delta)

    # bounce-back: thrown back toward the hellhound, smoothly over a few frames
    invuln = max(invuln - delta, 0.0)
    if knock_left > 0.0:
        var step = min(knock_left, 900.0 * delta)
        player.position.x -= step
        knock_left -= step

    var gap = player.position.x - _front_x()
    # the closer the hellhound, the louder the chase drums (matches the red danger bar)
    var danger = clamp((1.0 - gap / cfg['gap']) / 0.65, 0.0, 1.0)
    Audio.set_chase(danger)
    growl_timer -= delta
    if danger > 0.7 and growl_timer <= 0.0:
        Audio.sfx('growl', -3.0, randf_range(0.9, 1.1))
        growl_timer = 2.6
    var caught = false
    for c in chasers:
        if player.position.x - c['node'].position.x <= c['st']['reach']:
            caught = true
    if caught:
        _caught()
    elif not endless and player.position.x >= finish_x:
        _won()

# called by Player.stumble() every time you hit an obstacle
func on_obstacle_hit():
    if state != 'running' or invuln > 0.0:
        return
    hits += 1
    invuln = INVULN_TIME
    knock_left = KNOCKBACK
    if GameData.cheat_god:
        return          # unlimited health: still bounced back, but no heart lost
    hearts -= 1
    _update_hearts()
    if hearts <= 0:
        _caught()

# saves the run to the leaderboard (not when cheats were used)
func _record(result):
    if cheated:
        return []
    var prog = clamp((player.position.x - START_X) / (finish_x - START_X), 0.0, 1.0)
    if result == 'escaped':
        prog = 1.0
    return GameData.record_result({'level': GameData.level_index, 'char': GameData.selected_character,
            'result': result, 'time': time, 'hits': hits, 'progress': prog})

func _process(_delta):
    time_label.text = GameData.format_time(time)
    var done = clamp((player.position.x - START_X) / (finish_x - START_X), 0.0, 1.0)
    if endless:
        var dist_m = maxf(player.position.x - START_X, 0.0) / 10.0
        done = fmod(dist_m, 500.0) / 500.0         # the bar fills toward your next heart
        free_label.text = 'DISTANCE  %d m      BEST  %d m' % [int(dist_m), int(maxf(GameData.free_best, dist_m))]
    progress_fill.size.x = 600.0 * done
    var safe = clamp((player.position.x - _front_x()) / cfg['gap'], 0.0, 1.0)
    gap_fill.size.x = 600.0 * safe
    if safe < 0.35:
        gap_fill.color = Color(1.0, 0.15, 0.15)
    else:
        gap_fill.color = Color(0.3, 0.9, 0.4)

func _caught():
    state = 'caught'
    Audio.sfx('caught')
    Audio.duck(1.6)
    player.active = false
    if endless:
        await _free_game_over()
        return
    _record('caught')
    banner.text = 'CAUGHT!'
    await get_tree().create_timer(1.2).timeout
    get_tree().reload_current_scene()

func _won():
    state = 'won'
    Audio.sfx('win')
    Audio.set_chase(0.0)
    Audio.duck(3.5)
    player.active = false
    GameData.total_time += time
    var newly = _record('escaped')
    var msg = 'ESCAPED!\n' + GameData.format_time(time)
    if cheated:
        msg += '\n(cheats: not saved)'
    else:
        if GameData.last_was_best:
            msg += '\nNEW BEST!'
        for n in newly:
            msg += '\nUNLOCKED: ' + n.to_upper()
    banner.text = msg
    await get_tree().create_timer(2.2 if newly.size() == 0 else 3.6).timeout
    GameData.level_index += 1
    if GameData.level_index >= GameData.levels.size():
        get_tree().change_scene_to_file('res://Scenes/Credits.tscn')
    else:
        get_tree().reload_current_scene()

func _unhandled_input(event):
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE or event.keycode == KEY_P:
            try_pause()

# =====================================================================
# FREE PLAY
# Endless run. The track is built a little ahead of you as you go, and old pieces are removed.
# Monsters join the hunt the further you get (see FREE_STAGES), obstacles get closer together,
# and you win a heart back every 500 m. Your best distance is saved.
# =====================================================================

func _free_setup_cfg():
    var parts = cfg['title'].split(': ')
    cfg['title'] = 'FREE PLAY: ' + (parts[1] if parts.size() > 1 else cfg['title'])
    cfg['story'] = 'No chapel. No finish line.\nRun until you fall.'
    cfg['length'] = 300000.0
    cfg['monsters'] = ['hellhound']         # more join as you get further

func _free_init():
    free_obs_rng.seed = randi()
    free_deco_rng.seed = randi()
    free_next_obs = 1300.0
    free_next_deco = -200.0
    _free_spawn()

# builds scenery and obstacles up to 2600 px ahead of the runner and removes what is far behind
func _free_spawn():
    var px = player.position.x if player != null else START_X
    var limit = px + 2600.0
    var prog = clamp((px - START_X) / 40000.0, 0.0, 1.0)
    while free_next_deco < limit + 400.0:
        var d = _make_deco(free_deco_rng)
        d.position = Vector2(free_next_deco, GROUND_Y)
        d.z_index = -5
        add_child(d)
        free_deco.append(d)
        free_next_deco += free_deco_rng.randf_range(140.0, 380.0)
    while free_next_obs < limit:
        var rng = free_obs_rng
        var o = ObstacleScript.new()
        if rng.randf() < cfg['pad_chance']:
            o.is_pad = true
            o.size = Vector2(80, 18)
            o.color = Color(1.0, 0.85, 0.2)
            o.sprite_name = 'bouncepad'
        else:
            var types = cfg['types'] if prog > 0.05 else ['crate', 'wide']     # tall walls only after the warm-up
            var kind = types[rng.randi() % types.size()]
            o.color = cfg['obstacle_color']
            if kind == 'crate':
                o.size = Vector2(50, 50)
                o.sprite_name = 'crate'
            elif kind == 'wide':
                o.size = Vector2(110, 44)
                o.sprite_name = 'barrier'
            else:
                o.size = Vector2(60, 96)
                o.sprite_name = 'wall'
        o.position = Vector2(free_next_obs, GROUND_Y)
        o.z_index = 1
        add_child(o)
        free_obs.append(o)
        free_next_obs += rng.randf_range(cfg['spacing_min'], cfg['spacing_max']) * lerpf(1.0, 0.72, prog)
        if o.is_pad:
            free_next_obs += 450.0
    while free_obs.size() > 0 and free_obs[0].position.x < px - 1800.0:
        free_obs.pop_front().queue_free()
    while free_deco.size() > 0 and free_deco[0].position.x < px - 1800.0:
        free_deco.pop_front().queue_free()

func _free_tick(delta):
    free_tick -= delta
    if free_tick > 0.0:
        return
    free_tick = 0.15
    _free_spawn()
    var dist = player.position.x - START_X
    var p = _free_power()
    for c in chasers:
        c['st'] = GameData.chaser_stats(c['kind'], GameData.level_index, p)      # monsters keep getting stronger
    if free_stage < FREE_STAGES.size() and dist >= FREE_STAGES[free_stage][0]:
        var kind = FREE_STAGES[free_stage][1]
        free_stage += 1
        _add_chaser(kind, player.position.x - 1100.0)
        _flash_banner('A %s JOINS THE HUNT!' % GameData.monsters[kind]['name'])
        Audio.sfx('howl', -4.0)
    var mark = int(dist / 5000.0)
    if mark > free_heal_mark:
        free_heal_mark = mark
        if hearts < max_hearts:
            hearts += 1
            _update_hearts()
            Audio.sfx('recover')
            _flash_banner('+1 HEART')

func _flash_banner(text):
    banner.add_theme_font_size_override('font_size', 40)
    banner.text = text
    var tw = create_tween()
    tw.tween_interval(1.8)
    tw.tween_callback(func():
        if state == 'running':
            banner.text = ''
            banner.add_theme_font_size_override('font_size', 56))

func _free_game_over():
    var dist_m = int(maxf(player.position.x - START_X, 0.0) / 10.0)
    var is_best = false
    if not cheated:
        is_best = GameData.record_free(float(dist_m))
    var msg = 'GAME OVER\nDISTANCE  %d m' % dist_m
    if cheated:
        msg += '\n(cheats: not saved)'
    else:
        msg += '\nBEST  %d m' % int(GameData.free_best)
        if is_best:
            msg += '\nNEW BEST!'
    banner.add_theme_font_size_override('font_size', 48)
    banner.text = msg
    await get_tree().create_timer(3.0).timeout
    # next run: a different random world
    var nxt = randi() % GameData.levels.size()
    while GameData.levels.size() > 1 and nxt == GameData.level_index:
        nxt = randi() % GameData.levels.size()
    GameData.level_index = nxt
    get_tree().reload_current_scene()
