extends Node

# ---------- run state ----------
var selected_character = 'Elias'
var level_index = 0        # 0 = Level 1
var total_time = 0.0       # sum of winning times across levels
var free_play = false      # true = endless FREE PLAY mode (only dying ends it)
var free_best = 0.0        # best FREE PLAY distance, in metres

# ---------- characters ----------
# speed   = running speed (px/s)
# jump    = jump strength (higher = higher jump)
# stumble = fraction of speed kept after hitting an obstacle (higher = hurts less)
var characters = {
    'Elias':  {'speed': 350.0, 'jump': 720.0, 'stumble': 0.40, 'color': Color(0.85, 0.20, 0.20), 'desc': 'FAST\nRuns quickest'},
    'Victor': {'speed': 300.0, 'jump': 860.0, 'stumble': 0.40, 'color': Color(0.25, 0.40, 0.90), 'desc': 'HIGH JUMP\nClears anything'},
    'Lucian': {'speed': 300.0, 'jump': 720.0, 'stumble': 0.75, 'color': Color(0.20, 0.70, 0.35), 'desc': 'TOUGH\nBarely slows when hit'},
    # ---- unlockable characters ('unlock' says how to get them) ----
    'Selene': {'speed': 330.0, 'jump': 780.0, 'stumble': 0.55, 'color': Color(0.65, 0.25, 0.80), 'hair': Color(0.90, 0.90, 0.95), 'pants': Color(0.12, 0.10, 0.20),
               'desc': 'BALANCED\nGood at everything', 'unlock': {'levels': 2}},
    'Dante':  {'speed': 385.0, 'jump': 700.0, 'stumble': 0.30, 'color': Color(0.95, 0.55, 0.15), 'hair': Color(0.55, 0.10, 0.05), 'pants': Color(0.20, 0.12, 0.08),
               'desc': 'SPRINTER\nFastest, but fragile', 'unlock': {'levels': 4}},
    'Mira':   {'speed': 310.0, 'jump': 960.0, 'stumble': 0.60, 'color': Color(0.15, 0.75, 0.75), 'hair': Color(0.10, 0.10, 0.30), 'pants': Color(0.10, 0.20, 0.25),
               'desc': 'ACROBAT\nLeaps over anything', 'unlock': {'levels': 6}},
    'Maximus': {'speed': 365.0, 'jump': 840.0, 'stumble': 0.70, 'color': Color(1.0, 0.82, 0.25), 'hair': Color(0.35, 0.20, 0.05), 'pants': Color(0.30, 0.05, 0.05), 'cape': Color(0.70, 0.10, 0.10),
               'desc': 'LEGEND\nBest at everything', 'unlock': {'hard_all': true}}
}

# ---------- levels ----------
# THIS TABLE IS THE WHOLE GAME DESIGN. To change a level, change numbers here.
# length          = how far you must run (px)
# gap             = starting distance between you and the pursuer (px)
# ratio           = pursuer speed as a fraction of YOUR base speed (1.0 = same speed)
# spacing_min/max = distance between obstacles (smaller = harder)
# pad_chance      = chance (0 to 1) that a slot becomes a bounce pad instead of an obstacle
# types           = obstacle kinds: 'crate' (low), 'wide' (long and low), 'tall' (needs a big jump)
# deco            = scenery: 'house', 'tree', 'pillar', 'post'
var levels = [
    {
        'title': 'LEVEL 1: THE VILLAGE',
        'story': 'Something is hunting you.\nReach the chapel.',
        'length': 7000.0, 'gap': 560.0,
        'spacing_min': 380.0, 'spacing_max': 620.0, 'pad_chance': 0.10,
        'types': ['crate', 'wide'],
        'monsters': ['hellhound'], 'music': 'level1',
        'sky': Color(0.05, 0.07, 0.18), 'ground': Color(0.13, 0.13, 0.18),
        'deco': 'house', 'deco_color': Color(0.09, 0.10, 0.24),
        'pursuer_color': Color(0.45, 0.05, 0.05), 'obstacle_color': Color(0.45, 0.30, 0.15)
    },
    {
        'title': 'LEVEL 2: THE FOREST',
        'story': 'It follows you into the trees.\nIt is not alone.',
        'length': 9000.0, 'gap': 540.0,
        'spacing_min': 340.0, 'spacing_max': 560.0, 'pad_chance': 0.12,
        'types': ['crate', 'wide', 'tall'],
        'monsters': ['hellhound', 'vampire'], 'music': 'level2',
        'sky': Color(0.03, 0.10, 0.12), 'ground': Color(0.07, 0.16, 0.09),
        'deco': 'tree', 'deco_color': Color(0.04, 0.17, 0.12),
        'pursuer_color': Color(0.40, 0.05, 0.10), 'obstacle_color': Color(0.40, 0.28, 0.12)
    },
    {
        'title': 'LEVEL 3: THE MONASTERY',
        'story': 'The priests hold the gate.\nKeep running.',
        'length': 11000.0, 'gap': 520.0,
        'spacing_min': 320.0, 'spacing_max': 530.0, 'pad_chance': 0.16,
        'types': ['crate', 'wide', 'tall'],
        'monsters': ['vampire', 'werewolf'], 'music': 'level3',
        'sky': Color(0.15, 0.07, 0.17), 'ground': Color(0.17, 0.14, 0.17),
        'deco': 'pillar', 'deco_color': Color(0.22, 0.12, 0.25),
        'pursuer_color': Color(0.35, 0.03, 0.15), 'obstacle_color': Color(0.35, 0.30, 0.35)
    },
    {
        'title': 'LEVEL 4: THE CATACOMBS',
        'story': 'Something older wakes below.\nThe dead run too.',
        'length': 12000.0, 'gap': 510.0,
        'spacing_min': 310.0, 'spacing_max': 520.0, 'pad_chance': 0.16,
        'types': ['crate', 'wide', 'tall'],
        'monsters': ['wraith', 'hellhound', 'vampire'], 'music': 'catacombs',
        'sky': Color(0.03, 0.05, 0.07), 'ground': Color(0.12, 0.13, 0.15),
        'deco': 'gravestone', 'deco_color': Color(0.10, 0.13, 0.17),
        'pursuer_color': Color(0.30, 0.40, 0.55), 'obstacle_color': Color(0.28, 0.30, 0.34)
    },
    {
        'title': 'LEVEL 5: THE SWAMP',
        'story': 'The fog hides what hunts you.',
        'length': 13000.0, 'gap': 500.0,
        'spacing_min': 300.0, 'spacing_max': 510.0, 'pad_chance': 0.15,
        'types': ['crate', 'wide', 'tall'],
        'monsters': ['werewolf', 'wraith', 'hellhound'], 'music': 'swamp',
        'sky': Color(0.06, 0.12, 0.10), 'ground': Color(0.09, 0.15, 0.11),
        'deco': 'tree', 'deco_color': Color(0.05, 0.14, 0.10),
        'pursuer_color': Color(0.30, 0.20, 0.12), 'obstacle_color': Color(0.30, 0.25, 0.12)
    },
    {
        'title': 'LEVEL 6: THE BURNING PASS',
        'story': 'The mountain splits open.\nSomething huge climbs out.',
        'length': 14000.0, 'gap': 490.0,
        'spacing_min': 290.0, 'spacing_max': 500.0, 'pad_chance': 0.15,
        'types': ['crate', 'wide', 'tall'],
        'monsters': ['demon', 'werewolf', 'vampire'], 'music': 'hell',
        'sky': Color(0.24, 0.07, 0.06), 'ground': Color(0.20, 0.09, 0.07),
        'deco': 'spire', 'deco_color': Color(0.16, 0.05, 0.05),
        'pursuer_color': Color(0.60, 0.08, 0.06), 'obstacle_color': Color(0.25, 0.10, 0.08)
    },
    {
        'title': 'LEVEL 7: THE GATES OF HELL',
        'story': 'They are all here now.',
        'length': 15500.0, 'gap': 480.0,
        'spacing_min': 280.0, 'spacing_max': 490.0, 'pad_chance': 0.14,
        'types': ['crate', 'wide', 'tall'],
        'monsters': ['demon', 'wraith', 'hellhound', 'vampire'], 'music': 'hell',
        'sky': Color(0.20, 0.02, 0.05), 'ground': Color(0.15, 0.04, 0.05),
        'deco': 'spire', 'deco_color': Color(0.10, 0.02, 0.04),
        'pursuer_color': Color(0.60, 0.08, 0.06), 'obstacle_color': Color(0.22, 0.06, 0.06)
    },
    {
        'title': 'LEVEL 8: THE ROAD TO DAWN',
        'story': 'The sun is almost up.\nDo not stop.',
        'length': 17000.0, 'gap': 470.0,
        'spacing_min': 270.0, 'spacing_max': 480.0, 'pad_chance': 0.14,
        'types': ['crate', 'wide', 'tall'],
        'monsters': ['demon', 'werewolf', 'wraith', 'vampire'], 'music': 'level4',
        'sky': Color(0.60, 0.32, 0.22), 'ground': Color(0.28, 0.21, 0.15),
        'deco': 'post', 'deco_color': Color(0.40, 0.22, 0.20),
        'pursuer_color': Color(0.30, 0.02, 0.05), 'obstacle_color': Color(0.30, 0.20, 0.10)
    }
]

# =====================================================================
# MONSTERS. Every chaser type, and what it can do.
# base      = its speed as a fraction of YOUR speed (before it gets stronger)
# dash_at   = monster power needed before it learns to lunge (0 = always, 99 = never)
# frenzy    = true: it speeds up the longer the level lasts
# blink     = true: it teleports forward in short jumps
# reach     = how close it must get to catch you (px)
# =====================================================================
var monsters = {
    'hellhound': {'name': 'HELLHOUND', 'base': 0.88, 'dash_at': 0.5, 'frenzy': false, 'blink': false, 'reach': 75.0},
    'vampire':   {'name': 'VAMPIRE',   'base': 0.86, 'dash_at': 0.0, 'frenzy': false, 'blink': false, 'reach': 70.0},
    'werewolf':  {'name': 'WEREWOLF',  'base': 0.87, 'dash_at': 99.0, 'frenzy': true, 'blink': false, 'reach': 80.0},
    'wraith':    {'name': 'WRAITH',    'base': 0.85, 'dash_at': 99.0, 'frenzy': false, 'blink': true, 'reach': 70.0},
    'demon':     {'name': 'DEMON',     'base': 0.90, 'dash_at': 0.0, 'frenzy': true, 'blink': false, 'reach': 95.0}
}

# How strong monsters are in a level: 0 on level 1, rising to the difficulty's 'power' on the last level.
# Easy grows slowly, Normal steadily, Hard savagely.
func monster_power(level_i):
    var progress = float(level_i) / float(max(levels.size() - 1, 1))
    return progress * difficulty_data()['power']

# The full stat sheet for one chaser in one level.
func chaser_stats(kind, level_i, p_override = -1.0):
    var m = monsters[kind]
    var d = difficulty_data()
    var p = monster_power(level_i) if p_override < 0.0 else p_override      # FREE PLAY passes its own power
    var st = {'kind': kind, 'reach': m['reach'], 'power': p}
    st['ratio'] = min((m['base'] + 0.07 * p) * d['ratio'], 1.0)        # never faster than you on average
    st['dash_mult'] = 0.0
    st['rec'] = 1.0
    st['blink'] = 0.0
    st['frenzy'] = 0.0
    st['interval'] = 0.0                                               # seconds between lunges / blinks
    if m['blink']:
        st['blink'] = 120.0 + 90.0 * p                                 # how far it jumps (px)
        st['interval'] = max(9.0 - 4.5 * p, 3.2)
    elif p >= m['dash_at']:
        st['dash_mult'] = 1.30 + 0.35 * p                              # lunge speed
        st['rec'] = max(1.0 - (st['dash_mult'] - 1.0) * 0.5, 0.4)      # it tires afterwards
        st['interval'] = max(7.0 - 3.5 * p, 2.6)
    if m['frenzy']:
        st['frenzy'] = 0.02 + 0.03 * p
    return st

func format_time(t):
    var m = int(t / 60.0)
    var s = t - m * 60.0
    var whole = int(s)
    var hundredths = int((s - whole) * 100.0)
    return '%02d:%02d.%02d' % [m, whole, hundredths]


# =====================================================================
# DIFFICULTY  (chosen on the Difficulty screen)
# hearts  = how many hits you can take
# ratio   = multiplier on the monsters' speed (they never average faster than you)
# power   = how much stronger monsters get from level to level (see monster_power)
# spacing = multiplier on distance between obstacles (smaller = more crowded)
# gap     = multiplier on your head start
# pads    = multiplier on bounce-pad chance
# =====================================================================
const DIFFICULTIES = ['Easy', 'Normal', 'Hard']
var difficulty = 'Normal'
var difficulty_table = {
    'Easy':   {'hearts': 5, 'ratio': 0.92, 'power': 0.5, 'spacing': 1.25, 'gap': 1.20, 'pads': 1.6,
               'lines': ['5 hearts', 'Slower monsters', 'Monsters grow stronger slowly', 'Fewer obstacles', 'More bounce pads']},
    'Normal': {'hearts': 3, 'ratio': 1.00, 'power': 1.0, 'spacing': 1.00, 'gap': 1.00, 'pads': 1.0,
               'lines': ['3 hearts', 'Normal monsters', 'Monsters grow stronger', 'Normal obstacles', 'Normal bounce pads']},
    'Hard':   {'hearts': 2, 'ratio': 1.04, 'power': 1.7, 'spacing': 0.82, 'gap': 0.85, 'pads': 0.6,
               'lines': ['2 hearts', 'Relentless monsters', 'Monsters grow SAVAGE', 'Crowded track', 'Few bounce pads']}
}

func difficulty_data():
    return difficulty_table[difficulty]

# the level table, adjusted for the chosen difficulty
func level_cfg(i):
    var c = levels[i].duplicate(true)
    var d = difficulty_data()
    c['spacing_min'] = c['spacing_min'] * d['spacing']
    c['spacing_max'] = c['spacing_max'] * d['spacing']
    c['gap'] = c['gap'] * d['gap']
    c['pad_chance'] = min(c['pad_chance'] * d['pads'], 0.4)
    return c

# =====================================================================
# CHEATS  (pause menu). Runs played with cheats are NOT saved.
# =====================================================================
var cheat_god = false      # unlimited health
var cheat_speed = false    # speed boost
var cheat_jump = false     # jump boost

func any_cheat():
    return cheat_god or cheat_speed or cheat_jump

func speed_mult():
    return 1.5 if cheat_speed else 1.0

func jump_mult():
    return 1.25 if cheat_jump else 1.0

# =====================================================================
# SAVE DATA, UNLOCKS, LEADERBOARD
# =====================================================================
const SAVE_PATH = 'user://run_to_dawn_save.json'
var cleared = [false, false, false, false]        # levels escaped (any difficulty)
var hard_cleared = [false, false, false, false]   # levels escaped on Hard
var best_time = {}                                # '0|Normal' -> best seconds
var runs = []                                     # history of every run (newest last)
var stats = {'runs': 0, 'escapes': 0, 'caught': 0, 'hits': 0, 'play_time': 0.0}
var last_was_best = false

func _ready():
    cleared = []
    hard_cleared = []
    for i in range(levels.size()):
        cleared.append(false)
        hard_cleared.append(false)
    load_game()

func save_game():
    var data = {'difficulty': difficulty, 'cleared': cleared, 'hard_cleared': hard_cleared,
            'best_time': best_time, 'runs': runs, 'stats': stats, 'free_best': free_best}
    var f = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f != null:
        f.store_string(JSON.stringify(data))
        f.close()

func load_game():
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var f = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if f == null:
        return
    var data = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(data) != TYPE_DICTIONARY:
        return
    difficulty = data.get('difficulty', 'Normal')
    if not difficulty_table.has(difficulty):
        difficulty = 'Normal'
    for i in range(levels.size()):
        cleared[i] = bool(data.get('cleared', [])[i]) if i < data.get('cleared', []).size() else false
        hard_cleared[i] = bool(data.get('hard_cleared', [])[i]) if i < data.get('hard_cleared', []).size() else false
    best_time = data.get('best_time', {})
    runs = data.get('runs', [])
    free_best = float(data.get('free_best', 0.0))
    var st = data.get('stats', {})
    for k in stats.keys():
        if st.has(k):
            stats[k] = st[k]

func cleared_count():
    var n = 0
    for c in cleared:
        if c:
            n += 1
    return n

func is_unlocked(cname):
    var d = characters[cname]
    if not d.has('unlock'):
        return true
    var u = d['unlock']
    if u.has('levels'):
        return cleared_count() >= u['levels']
    if u.has('hard_all'):
        for c in hard_cleared:
            if not c:
                return false
        return true
    return true

func unlock_text(cname):
    var u = characters[cname].get('unlock', {})
    if u.has('levels'):
        return 'Clear %d levels' % u['levels']
    if u.has('hard_all'):
        return 'Clear all levels on HARD'
    return ''

func unlocked_count():
    var n = 0
    for k in characters.keys():
        if is_unlocked(k):
            n += 1
    return n

# Called by Level when a run ends. r = {level, char, result ('escaped'/'caught'), time, hits, progress}
# Returns the names of characters this run unlocked.
func record_result(r):
    var before = []
    for k in characters.keys():
        if is_unlocked(k):
            before.append(k)
    r['diff'] = difficulty
    r['date'] = Time.get_datetime_string_from_system(false, true)
    runs.append(r)
    if runs.size() > 200:
        runs.pop_front()
    stats['runs'] = int(stats['runs']) + 1
    stats['hits'] = int(stats['hits']) + int(r['hits'])
    stats['play_time'] = float(stats['play_time']) + float(r['time'])
    last_was_best = false
    if r['result'] == 'escaped':
        stats['escapes'] = int(stats['escapes']) + 1
        cleared[r['level']] = true
        if difficulty == 'Hard':
            hard_cleared[r['level']] = true
        var key = '%d|%s' % [r['level'], difficulty]
        if not best_time.has(key) or r['time'] < best_time[key]:
            best_time[key] = r['time']
            last_was_best = true
    else:
        stats['caught'] = int(stats['caught']) + 1
    save_game()
    var newly = []
    for k in characters.keys():
        if is_unlocked(k) and not before.has(k):
            newly.append(k)
    return newly

# Called by Level when a FREE PLAY run ends (dist = metres). Returns true if it is a new best.
func record_free(dist):
    var is_best = dist > free_best
    if is_best:
        free_best = dist
    save_game()
    return is_best
