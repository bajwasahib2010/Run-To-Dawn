extends RefCounted
# Shared look for all menus: dark pixel style, buttons, labels, night backdrop.

const GOLD = Color(1.0, 0.82, 0.25)
const CREAM = Color(1.0, 0.95, 0.85)
const RED = Color(0.9, 0.2, 0.18)
const GREEN = Color(0.35, 0.9, 0.45)

static func _box(bg, border):
    var s = StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(4)
    s.set_content_margin_all(8)
    return s

static func style_button(b, size = 28, accent = Color(0.55, 0.22, 0.28)):
    b.add_theme_stylebox_override('normal', _box(Color(0.10, 0.07, 0.16), accent))
    b.add_theme_stylebox_override('hover', _box(Color(0.20, 0.08, 0.13), GOLD))
    b.add_theme_stylebox_override('pressed', _box(Color(0.30, 0.10, 0.15), GOLD))
    b.add_theme_stylebox_override('focus', _box(Color(0.20, 0.08, 0.13), GOLD))
    b.add_theme_stylebox_override('disabled', _box(Color(0.08, 0.08, 0.10), Color(0.2, 0.2, 0.25)))
    b.add_theme_font_size_override('font_size', size)
    for c in ['font_color', 'font_hover_color', 'font_pressed_color', 'font_focus_color']:
        b.add_theme_color_override(c, CREAM)

static func make_button(text, size, pos, dim, accent = Color(0.55, 0.22, 0.28)):
    var b = Button.new()
    b.text = text
    b.position = pos
    b.size = dim
    style_button(b, size, accent)
    b.mouse_entered.connect(func(): Audio.sfx('hover', -6.0))
    b.pressed.connect(func(): Audio.sfx('click'))
    return b

static func make_label(text, size, color, pos, w, align = HORIZONTAL_ALIGNMENT_CENTER):
    var l = Label.new()
    l.text = text
    l.position = pos
    l.size = Vector2(w, size * 1.5 * (1 + text.count('\n')))
    l.horizontal_alignment = align
    l.add_theme_font_size_override('font_size', size)
    l.add_theme_color_override('font_color', color)
    l.add_theme_color_override('font_outline_color', Color.BLACK)
    l.add_theme_constant_override('outline_size', 6)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return l

static func make_rect(parent, pos, dim, color):
    var r = ColorRect.new()
    r.position = pos
    r.size = dim
    r.color = color
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(r)
    return r

# night-time village backdrop, drawn inside a Control's _draw()
static func draw_night(c, t):
    c.draw_rect(Rect2(0, 0, 1280, 720), Color(0.03, 0.04, 0.11))
    c.draw_rect(Rect2(0, 300, 1280, 150), Color(0.05, 0.06, 0.16))
    c.draw_rect(Rect2(0, 450, 1280, 130), Color(0.08, 0.08, 0.20))
    for i in range(60):
        var sx = fposmod(i * 733.0, 1280.0)
        var sy = fposmod(i * 311.0, 360.0) + 20.0
        var a = 0.3 + 0.5 * (0.5 + 0.5 * sin(t * 2.0 + i))
        c.draw_rect(Rect2(sx, sy, 4, 4), Color(1, 1, 0.9, a))
    # pixel moon
    for j in range(-7, 8):
        var hw = int(sqrt(maxf(49.0 - j * j, 0.0)) + 0.5)
        c.draw_rect(Rect2(1040 - hw * 8, 130 + j * 8, hw * 16, 8), Color(0.93, 0.93, 0.8))
    # houses
    for i in range(6):
        var x = i * 250.0 - 40.0
        var h = 120.0 + (i * 53 % 4) * 20.0
        var by = 600.0
        c.draw_rect(Rect2(x, by - h, 200, h), Color(0.06, 0.07, 0.16))
        for k in range(6):
            c.draw_rect(Rect2(x - 14 + k * 14, by - h - (k + 1) * 14, 228 - 28 * k, 14), Color(0.05, 0.05, 0.13))
        var lit = Color(1.0, 0.75, 0.3, 0.5 + 0.4 * sin(t * 3.0 + i)) if i == 2 else Color(0.03, 0.04, 0.09)
        c.draw_rect(Rect2(x + 30, by - h + 36, 34, 34), lit)
    c.draw_rect(Rect2(0, 600, 1280, 120), Color(0.10, 0.09, 0.13))
    c.draw_rect(Rect2(0, 600, 1280, 6), Color(0.2, 0.19, 0.26))
