extends Control
# Character select with locked characters. Clear levels to unlock more.

const UIKit = preload('res://Scripts/UIKit.gd')
const Art = preload('res://Scripts/Art.gd')
const RunnerScript = preload('res://Scripts/PixelRunner.gd')

var names = []
var selected = ''
var cards = {}
var info_label
var toast
var t = 0.0

func _ready():
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    Audio.play_music('menu')
    names = GameData.characters.keys()
    selected = GameData.selected_character
    if not names.has(selected) or not GameData.is_unlocked(selected):
        selected = names[0]
    add_child(UIKit.make_label('CHOOSE YOUR RUNNER', 56, UIKit.GOLD, Vector2(0, 30), 1280))

    var cw = 150.0
    var gap = 12.0
    var x0 = (1280.0 - (names.size() * cw + (names.size() - 1) * gap)) / 2.0
    for i in range(names.size()):
        _build_card(names[i], Vector2(x0 + i * (cw + gap), 120), cw)

    info_label = UIKit.make_label('', 24, UIKit.CREAM, Vector2(0, 535), 1280)
    add_child(info_label)
    toast = UIKit.make_label('', 22, UIKit.RED, Vector2(0, 580), 1280)
    add_child(toast)
    var start = UIKit.make_button('START', 32, Vector2(470, 630), Vector2(340, 64))
    start.pressed.connect(_start)
    add_child(start)
    var back = UIKit.make_button('BACK', 26, Vector2(40, 636), Vector2(160, 54))
    back.pressed.connect(func(): get_tree().change_scene_to_file('res://Scenes/Difficulty.tscn'))
    add_child(back)
    add_child(UIKit.make_label('Levels cleared: %d/%d' % [GameData.cleared_count(), GameData.levels.size()],
            20, UIKit.CREAM, Vector2(1000, 650), 240, HORIZONTAL_ALIGNMENT_RIGHT))
    _refresh()
    cards[selected].grab_focus()

func _norm(v, lo, hi):
    return clampf((v - lo) / (hi - lo), 0.05, 1.0)

func _build_card(cname, pos, w):
    var d = GameData.characters[cname]
    var b = Button.new()
    b.position = pos
    b.size = Vector2(w, 390)
    b.pressed.connect(_pick.bind(cname))
    add_child(b)
    cards[cname] = b
    b.add_child(UIKit.make_label(cname.to_upper(), 22, d['color'].lightened(0.3), Vector2(0, 10), w))

    # animated preview: the real PNG sprite if it exists, otherwise the pixel runner
    var holder = Node2D.new()
    holder.position = Vector2(w * 0.5, 190)
    holder.scale = Vector2(1.5, 1.5)
    b.add_child(holder)
    var sprite = Art.animated(cname.to_lower() + '_run', Vector2(24, 35),
            {'run': [0, 1, 2, 3, 4, 5], 'jump': [6], 'idle': [7]}, 2.0, 16.0)
    if sprite != null:
        sprite.play('run')
        holder.add_child(sprite)
    else:
        var r = RunnerScript.new()
        r.preview = true
        r.setup(d)
        holder.add_child(r)

    # stat bars
    var stats = [['SPEED', _norm(d['speed'], 280.0, 400.0)], ['JUMP', _norm(d['jump'], 680.0, 1000.0)],
            ['TOUGH', _norm(d['stumble'], 0.25, 0.8)]]
    var y = 232.0
    for s in stats:
        b.add_child(UIKit.make_label(s[0], 14, UIKit.CREAM, Vector2(12, y), 100, HORIZONTAL_ALIGNMENT_LEFT))
        UIKit.make_rect(b, Vector2(12, y + 24), Vector2(w - 24, 8), Color(0.2, 0.2, 0.25))
        UIKit.make_rect(b, Vector2(12, y + 24), Vector2((w - 24) * s[1], 8), d['color'])
        y += 44.0

    if not GameData.is_unlocked(cname):
        UIKit.make_rect(b, Vector2(4, 4), Vector2(w - 8, 382), Color(0, 0, 0, 0.78))
        b.add_child(UIKit.make_label('LOCKED', 26, UIKit.RED, Vector2(0, 130), w))
        b.add_child(UIKit.make_label(GameData.unlock_text(cname).replace(' ', '\n'), 17, UIKit.CREAM, Vector2(0, 175), w))

func _pick(cname):
    if not GameData.is_unlocked(cname):
        Audio.sfx('hit', -8.0)
        toast.text = '%s is locked: %s' % [cname.to_upper(), GameData.unlock_text(cname)]
        toast.modulate.a = 1.0
        create_tween().tween_property(toast, 'modulate:a', 0.0, 1.5).set_delay(1.2)
        return
    selected = cname
    Audio.sfx('select')
    _refresh()

func _refresh():
    for cname in cards.keys():
        var d = GameData.characters[cname]
        var accent = UIKit.GOLD if cname == selected else Color(0.35, 0.2, 0.25)
        UIKit.style_button(cards[cname], 20, accent)
    var d2 = GameData.characters[selected]
    info_label.text = selected.to_upper() + '  -  ' + d2['desc'].replace('\n', '  -  ')

func _start():
    GameData.selected_character = selected
    GameData.level_index = 0
    GameData.total_time = 0.0
    if GameData.free_play:
        GameData.level_index = randi() % GameData.levels.size()      # FREE PLAY: a random world each run
    get_tree().change_scene_to_file('res://Scenes/Level.tscn')

func _process(delta):
    t += delta
    queue_redraw()

func _draw():
    UIKit.draw_night(self, t)
