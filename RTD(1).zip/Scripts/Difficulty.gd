extends Control
# Pick Easy / Normal / Hard, then go on to character select.

const UIKit = preload('res://Scripts/UIKit.gd')
const COLORS = {'Easy': Color(0.30, 0.80, 0.40), 'Normal': Color(1.0, 0.82, 0.25), 'Hard': Color(0.90, 0.20, 0.18)}
var t = 0.0

func _ready():
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    Audio.play_music('menu')
    add_child(UIKit.make_label('CHOOSE DIFFICULTY', 64, UIKit.GOLD, Vector2(0, 50), 1280))
    if GameData.free_play:
        add_child(UIKit.make_label('FREE PLAY  -  endless, it only ends when you die', 26, UIKit.RED, Vector2(0, 130), 1280))
    var x = 100.0
    var current_btn = null
    for dname in GameData.DIFFICULTIES:
        var d = GameData.difficulty_table[dname]
        var text = dname.to_upper() + '\n\n' + '\n'.join(d['lines'])
        if dname == GameData.difficulty:
            text += '\n\n(last used)'
        var b = UIKit.make_button(text, 26, Vector2(x, 190), Vector2(340, 340), COLORS[dname])
        b.pressed.connect(_choose.bind(dname))
        add_child(b)
        if dname == GameData.difficulty:
            current_btn = b
        x += 390.0
    var back = UIKit.make_button('BACK', 26, Vector2(40, 640), Vector2(160, 54))
    back.pressed.connect(func(): get_tree().change_scene_to_file('res://Scenes/MainMenu.tscn'))
    add_child(back)
    add_child(UIKit.make_label('Hard unlocks the legendary Maximus when you clear every level.', 20, UIKit.CREAM, Vector2(0, 580), 1280))
    if current_btn != null:
        current_btn.grab_focus()

func _choose(dname):
    GameData.difficulty = dname
    GameData.save_game()
    get_tree().change_scene_to_file('res://Scenes/CharacterSelect.tscn')

func _process(delta):
    t += delta
    queue_redraw()

func _draw():
    UIKit.draw_night(self, t)
