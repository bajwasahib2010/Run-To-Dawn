extends Node2D
# Code-drawn pixel monsters, used when there is no PNG sprite for a chaser.
# The node's origin is the monster's FEET. Faces right (toward you).
# Level.gd sets warn (about to dash / blink) and dashing.

var kind = 'hellhound'
var warn = false
var dashing = false
var clock = 0.0

const SIZES = {            # [width in blocks, height in blocks, pixels per block]
    'hellhound': [18, 11, 8.0], 'vampire': [10, 16, 7.0], 'werewolf': [14, 15, 7.0],
    'wraith': [12, 17, 7.0], 'demon': [16, 20, 7.0]
}
const EYES = {
    'hellhound': Color(1.0, 0.85, 0.2), 'vampire': Color(1.0, 0.1, 0.1), 'werewolf': Color(1.0, 0.7, 0.1),
    'wraith': Color(0.4, 1.0, 1.0), 'demon': Color(1.0, 0.9, 0.2)
}
const WHITE = Color(1, 1, 1)

func _process(delta):
    clock += delta * (1.5 if dashing else 1.0)
    if warn:
        modulate = Color(1.5, 1.2, 1.2)
    elif dashing:
        modulate = Color(1.25, 0.9, 0.9)
    else:
        modulate = Color.WHITE
    queue_redraw()

func _eye():
    if warn and int(clock * 20.0) % 2 == 0:
        return WHITE
    return EYES[kind]

# one pixel block: gx,gy,gw,gh are in blocks (feet at the bottom of the grid)
func _b(gx, gy, gw, gh, c, bob = 0.0, dx = 0.0):
    var s = SIZES[kind]
    var u = s[2]
    draw_rect(Rect2(-s[0] * u * 0.5 + gx * u + dx, -s[1] * u + gy * u + bob, gw * u, gh * u), c)

# two running legs. x_back / x_front = block columns, 4 animation frames
func _legs(y, h, xb, xf, c, foot, fc, bob):
    var f = int(clock * 10.0) % 4
    var lb = 1 if f == 1 else 0
    var lf = 1 if f == 3 else 0
    var xs = [xb, xf]
    if f == 2:
        xs = [xf, xb]
    _b(xs[0], y, 2, h - lb, c, bob)
    _b(xs[0] - 1, y + h - lb, 3, foot, fc, bob)
    _b(xs[1], y, 2, h - lf, c, bob)
    _b(xs[1], y + h - lf, 3, foot, fc, bob)

func _draw():
    if kind == 'vampire':
        _vampire()
    elif kind == 'werewolf':
        _werewolf()
    elif kind == 'wraith':
        _wraith()
    elif kind == 'demon':
        _demon()
    else:
        _hellhound()

func _hellhound():
    var body = Color(0.38, 0.04, 0.05)
    var dark = Color(0.2, 0.02, 0.04)
    var spike = Color(0.1, 0.01, 0.03)
    var a = int(clock * 12.0) % 2
    var bob = -abs(sin(clock * 12.0)) * 3.0
    _b(1, 3, 2, 1, dark, bob)
    _b(0, 2, 1, 1, dark, bob)
    _b(3 + a, 7, 2, 4, dark)
    _b(6 - a, 7, 2, 4, dark)
    _b(10 + a, 7, 2, 4, dark)
    _b(12 - a, 7, 2, 4, dark)
    _b(3, 3, 10, 4, body, bob)
    _b(4, 6, 8, 1, dark, bob)
    _b(12, 2, 2, 4, body, bob)
    _b(13, 1, 4, 4, body, bob)
    _b(16, 3, 2, 2, body, bob)
    _b(13, 0, 1, 2, dark, bob)
    _b(15, 0, 1, 1, dark, bob)
    _b(14, 5, 1, 1, WHITE, bob)
    _b(16, 5, 1, 1, WHITE, bob)
    _b(15, 2, 1, 1, _eye(), bob)
    for gx in [4, 6, 8, 10]:
        _b(gx, 2, 1, 1, spike, bob)
        var h = int(1.0 + 2.0 * (0.5 + 0.5 * sin(clock * 14.0 + gx * 2.0)))
        _b(gx, 2 - h, 1, h, Color(1.0, 0.5, 0.08), bob)
        _b(gx, 2 - h, 1, 1, Color(1.0, 0.85, 0.2), bob)

func _vampire():
    var coat = Color(0.08, 0.06, 0.10)
    var red = Color(0.5, 0.05, 0.10)
    var pale = Color(0.86, 0.86, 0.92)
    var shoe = Color(0.03, 0.03, 0.04)
    var bob = -abs(sin(clock * 10.0)) * 4.0
    var flutter = sin(clock * 14.0) * 6.0
    _b(0, 3, 4, 9, coat, bob, flutter)         # cape streaming behind
    _b(1, 4, 2, 7, red, bob, flutter)
    _b(0, 11, 2, 2, coat, bob, flutter * 1.4)
    _legs(10, 5, 2, 5, Color(0.1, 0.08, 0.14), 1, shoe, bob)
    _b(3, 4, 4, 6, coat, bob)
    _b(5, 5, 1, 4, pale, bob)
    _b(3, 1, 4, 3, pale, bob)
    _b(3, 0, 4, 1, coat, bob)
    _b(3, 1, 1, 2, coat, bob)
    _b(6, 2, 1, 1, _eye(), bob)
    _b(6, 3, 1, 1, WHITE, bob)                  # fang
    _b(6, 5, 3, 1, coat, bob)                   # arm reaching for you
    _b(9, 5, 1, 1, pale, bob)

func _werewolf():
    var fur = Color(0.33, 0.22, 0.14)
    var dark = Color(0.2, 0.13, 0.08)
    var light = Color(0.6, 0.45, 0.3)
    var bob = -abs(sin(clock * 11.0)) * 4.0
    _b(0, 7, 3, 1, dark, bob, sin(clock * 12.0) * 3.0)
    _legs(10, 5, 3, 6, fur, 0, fur, bob)
    _b(3, 4, 6, 6, fur, bob)
    _b(2, 3, 4, 3, fur, bob)
    _b(8, 2, 4, 4, fur, bob)
    _b(11, 4, 3, 2, light, bob)
    _b(8, 1, 1, 2, dark, bob)
    _b(10, 1, 1, 1, dark, bob)
    _b(10, 3, 1, 1, _eye(), bob)
    _b(12, 6, 1, 1, WHITE, bob)
    _b(13, 6, 1, 1, WHITE, bob)
    _b(9, 6, 4, 1, fur, bob)
    _b(13, 6, 1, 2, WHITE, bob)

func _wraith():
    var robe = Color(0.55, 0.65, 0.80, 0.78)
    var dark = Color(0.18, 0.22, 0.38, 0.9)
    var light = Color(0.7, 0.85, 1.0, 0.7)
    var bob = sin(clock * 3.0) * 6.0 - 14.0      # it floats above the ground
    _b(3, 0, 6, 5, dark, bob)
    _b(4, 1, 4, 3, Color(0, 0, 0), bob)
    _b(5, 2, 1, 1, _eye(), bob)
    _b(7, 2, 1, 1, _eye(), bob)
    for r in range(10):
        var w = 6.0 + r * 0.45
        _b(6.0 - w * 0.5, 5 + r, w, 1, robe, bob, sin(clock * 4.0 + r * 0.8) * 5.0)
    for i in range(4):
        _b(2.0 + i * 2.2, 15, 1, 2.0 + sin(clock * 5.0 + i), Color(0.55, 0.65, 0.8, 0.5), bob)
    _b(9, 6, 3, 1, light, bob)
    _b(11, 5, 1, 1, light, bob)
    _b(11, 7, 1, 1, light, bob)

func _demon():
    var red = Color(0.62, 0.08, 0.06)
    var dark = Color(0.3, 0.03, 0.04)
    var bone = Color(0.9, 0.85, 0.7)
    var wing = Color(0.18, 0.02, 0.05)
    var bob = -abs(sin(clock * 9.0)) * 4.0
    var flap = sin(clock * 8.0) * 10.0
    _b(0, 2, 5, 9, wing, bob + flap)
    _b(1, 0, 3, 3, wing, bob + flap)
    _legs(14, 5, 5, 9, dark, 1, Color(0.1, 0.02, 0.02), bob)
    _b(4, 6, 8, 8, red, bob)
    _b(6, 8, 4, 4, dark, bob)
    _b(4, 13, 8, 1, dark, bob)
    for fx in [4, 11]:
        var fh = 1.0 + 1.5 * (0.5 + 0.5 * sin(clock * 15.0 + fx))
        _b(fx, 6 - fh, 1, fh, Color(1.0, 0.5, 0.08), bob)
    _b(7, 2, 5, 4, red, bob)
    _b(7, 0, 1, 3, bone, bob)
    _b(11, 0, 1, 3, bone, bob)
    _b(10, 3, 1, 1, _eye(), bob)
    _b(10, 6, 2, 1, WHITE, bob)
    _b(11, 8, 4, 2, red, bob)
    _b(15, 8, 1, 2, bone, bob)
