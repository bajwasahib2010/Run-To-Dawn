extends Control

var can_exit = false

func _ready():
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    Audio.play_music('ending')

    var bg = ColorRect.new()
    bg.color = Color(0.0, 0.0, 0.0)
    add_child(bg)
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var label = Label.new()
    label.text = 'THE TRAVELER ESCAPED\n\nTHE PRIESTS SACRIFICED\nTHEMSELVES FOR HIS SURVIVAL\n\nRUN TO DAWN\n\nTHE END\n\nTOTAL TIME  ' + GameData.format_time(GameData.total_time) + '\n\n(press any key)'
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override('font_size', 40)
    add_child(label)
    label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    await get_tree().create_timer(1.5).timeout
    can_exit = true

func _unhandled_input(event):
    if can_exit and event.is_pressed() and not event.is_echo():
        get_tree().change_scene_to_file('res://Scenes/MainMenu.tscn')
