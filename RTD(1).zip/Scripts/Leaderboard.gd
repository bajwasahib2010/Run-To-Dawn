extends Control
# Your personal leaderboard: best times, lifetime stats, and how recent runs compare to your earlier ones.

const UIKit = preload('res://Scripts/UIKit.gd')
var t = 0.0

func _ready():
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    Audio.play_music('menu')
    UIKit.make_rect(self, Vector2(20, 80), Vector2(1240, 630), Color(0, 0, 0, 0.62))
    add_child(UIKit.make_label('LEADERBOARD', 52, UIKit.GOLD, Vector2(0, 14), 1280))
    var back = UIKit.make_button('BACK', 24, Vector2(30, 20), Vector2(140, 50))
    back.pressed.connect(func(): get_tree().change_scene_to_file('res://Scenes/MainMenu.tscn'))
    add_child(back)
    back.grab_focus()
    _build_best_times()
    _build_stats()
    _build_recent()

func _L(text, size, color, x, y, w, align = HORIZONTAL_ALIGNMENT_LEFT):
    add_child(UIKit.make_label(text, size, color, Vector2(x, y), w, align))

func _short(i):
    var parts = GameData.levels[i]['title'].split(': ')
    return parts[parts.size() - 1]

func _build_best_times():
    _L('BEST TIMES', 30, UIKit.GOLD, 50, 96, 500)
    for j in range(GameData.DIFFICULTIES.size()):
        _L(GameData.DIFFICULTIES[j].to_upper(), 18, UIKit.CREAM, 310 + j * 110, 140, 110, HORIZONTAL_ALIGNMENT_CENTER)
    for i in range(GameData.levels.size()):
        var y = 174.0 + i * 28.0
        _L('L%d  %s' % [i + 1, _short(i)], 17, UIKit.CREAM, 50, y, 270)
        for j in range(GameData.DIFFICULTIES.size()):
            var key = '%d|%s' % [i, GameData.DIFFICULTIES[j]]
            var has = GameData.best_time.has(key)
            _L(GameData.format_time(GameData.best_time[key]) if has else '--', 16,
                    UIKit.GREEN if has else Color(0.5, 0.5, 0.55), 310 + j * 110, y, 110, HORIZONTAL_ALIGNMENT_CENTER)

func _build_stats():
    _L('LIFETIME STATS', 30, UIKit.GOLD, 50, 410, 500)
    var st = GameData.stats
    var total = int(st['runs'])
    var rate = int(round(100.0 * int(st['escapes']) / total)) if total > 0 else 0
    var hard = 0
    for c in GameData.hard_cleared:
        if c:
            hard += 1
    var lines = [
        'Runs played:  %d' % total,
        'Escapes:  %d      Caught:  %d' % [int(st['escapes']), int(st['caught'])],
        'Escape rate:  %d%%' % rate,
        'Obstacles hit:  %d' % int(st['hits']),
        'Time running:  %s' % GameData.format_time(float(st['play_time'])),
        'Levels cleared:  %d/%d      Hard clears:  %d/%d' % [GameData.cleared_count(), GameData.levels.size(), hard, GameData.levels.size()],
        'Characters unlocked:  %d/%d' % [GameData.unlocked_count(), GameData.characters.size()]
    ]
    for i in range(lines.size()):
        _L(lines[i], 20, UIKit.CREAM, 50, 452 + i * 31.0, 580)

func _build_recent():
    _L('RECENT RUNS', 30, UIKit.GOLD, 680, 96, 500)
    if GameData.runs.size() == 0:
        _L('No runs yet. Go escape!', 22, UIKit.CREAM, 680, 160, 500)
        return
    # work out, in order, how each run compared with your earlier runs
    var best_t = {}
    var best_p = {}
    var rows = []
    for r in GameData.runs:
        var key = '%d|%s' % [int(r['level']), r['diff']]
        var delta = null
        if r['result'] == 'escaped':
            if best_t.has(key):
                delta = float(r['time']) - best_t[key]
            if not best_t.has(key) or float(r['time']) < best_t[key]:
                best_t[key] = float(r['time'])
        else:
            if best_p.has(key):
                delta = float(r['progress']) - best_p[key]
        if not best_p.has(key) or float(r['progress']) > best_p[key]:
            best_p[key] = float(r['progress'])
        rows.append([r, delta])
    rows.reverse()
    var shown = mini(rows.size(), 8)
    for i in range(shown):
        var r = rows[i][0]
        var delta = rows[i][1]
        var y = 142.0 + i * 68.0
        _L('L%d  %s  %s' % [int(r['level']) + 1, str(r['diff']).to_upper(), str(r['char']).to_upper()], 19, UIKit.CREAM, 680, y, 420)
        _L(str(r['date']).substr(0, 10), 15, Color(0.6, 0.6, 0.68), 1090, y + 3, 150, HORIZONTAL_ALIGNMENT_RIGHT)
        var line = ''
        var col = UIKit.GREEN
        var dtext = ''
        var dcol = UIKit.CREAM
        if r['result'] == 'escaped':
            line = 'ESCAPED  ' + GameData.format_time(float(r['time']))
            if delta == null:
                dtext = 'first clear'
                dcol = UIKit.GOLD
            else:
                dtext = '%+.2fs' % delta
                dcol = UIKit.GREEN if delta < 0.0 else UIKit.RED
        else:
            col = UIKit.RED
            line = 'CAUGHT AT %d%%' % int(float(r['progress']) * 100.0)
            if delta != null:
                dtext = '%+d%%' % int(round(delta * 100.0))
                dcol = UIKit.GREEN if delta >= 0.0 else UIKit.RED
        _L(line, 19, col, 680, y + 26, 300)
        _L(dtext, 19, dcol, 960, y + 26, 150)
        _L('hits %d' % int(r['hits']), 17, Color(0.6, 0.6, 0.68), 1110, y + 28, 130, HORIZONTAL_ALIGNMENT_RIGHT)

func _process(delta):
    t += delta
    queue_redraw()

func _draw():
    UIKit.draw_night(self, t)
