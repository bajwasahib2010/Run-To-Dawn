extends RefCounted

# Makes a visual for anything in the game.
# If res://Sprites/<sprite_name>.png exists, it is used (scaled to size.y tall).
# Otherwise a colored box is drawn, so the game always runs.
# The visual's origin is the bottom-center (the feet).
static func visual(sprite_name, size, color):
    var path = 'res://Sprites/' + sprite_name + '.png'
    if ResourceLoader.exists(path):
        var s = Sprite2D.new()
        s.texture = load(path)
        s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST     # keep pixels crisp
        s.centered = false
        var tex_size = s.texture.get_size()
        var k = size.y / tex_size.y
        s.scale = Vector2(k, k)
        s.position = Vector2(-tex_size.x * k * 0.5, -size.y)
        return s
    var r = ColorRect.new()
    r.color = color
    r.size = size
    r.position = Vector2(-size.x * 0.5, -size.y)
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return r

# Animated visual from a horizontal sprite strip: res://Sprites/<sprite_name>.png
#   frame_size  = size of ONE frame in the strip, e.g. Vector2(24, 35)
#   anims       = {'run': [0, 1, 2, 3, 4, 5], 'jump': [6]}   (frame numbers, from the left)
#   pixel_scale = how many screen pixels one art pixel becomes (2.0 = chunky pixels)
# The origin is the bottom-center (the feet), like visual() above.
# Returns null if the PNG is missing, so the caller can fall back to visual().
static func animated(sprite_name, frame_size, anims, pixel_scale, fps):
    var path = 'res://Sprites/' + sprite_name + '.png'
    if not ResourceLoader.exists(path):
        return null
    var tex = load(path)
    var frames = SpriteFrames.new()
    frames.remove_animation('default')
    for anim_name in anims.keys():
        frames.add_animation(anim_name)
        frames.set_animation_speed(anim_name, fps)
        frames.set_animation_loop(anim_name, true)
        for i in anims[anim_name]:
            var atlas = AtlasTexture.new()
            atlas.atlas = tex
            atlas.region = Rect2(i * frame_size.x, 0, frame_size.x, frame_size.y)
            frames.add_frame(anim_name, atlas)
    var s = AnimatedSprite2D.new()
    s.sprite_frames = frames
    s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    s.centered = false
    s.offset = Vector2(-frame_size.x * 0.5, -frame_size.y)
    s.scale = Vector2(pixel_scale, pixel_scale)
    s.play(anims.keys()[0])
    return s
