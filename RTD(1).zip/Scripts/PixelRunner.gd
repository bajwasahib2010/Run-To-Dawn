extends Node2D
# Code-drawn pixel runner, used for characters that have no PNG sprite sheet.
# The node's origin is the runner's FEET. Faces right.

var shirt = Color(0.85, 0.2, 0.2)
var hair = Color(0.14, 0.09, 0.06)
var pants = Color(0.14, 0.16, 0.32)
var skin = Color(0.93, 0.74, 0.58)
var cape = null
var preview = false     # true = always running (character select cards)
var unit = 5.0
var mode = 'idle'
var speed = 1.0
var clock = 0.0

func setup(data):
    shirt = data['color']
    if data.has('hair'):
        hair = data['hair']
    if data.has('pants'):
        pants = data['pants']
    if data.has('cape'):
        cape = data['cape']

func _process(delta):
    var p = get_parent()
    if preview:
        mode = 'run'
        speed = 1.0
    elif p != null and p.has_method('current_speed'):
        if not p.active:
            mode = 'idle'
        elif not p.is_on_floor():
            mode = 'jump'
        else:
            mode = 'run'
            speed = clampf(p.current_speed() / p.base_speed, 0.45, 1.5)
    clock += delta * speed
    queue_redraw()

func _b(gx, gy, gw, gh, c, bob = 0.0):
    draw_rect(Rect2(-4.0 * unit + gx * unit, -14.0 * unit + gy * unit + bob, gw * unit, gh * unit), c)

func _draw():
    var u = unit
    var shoe = Color(0.06, 0.05, 0.05)
    var shirt2 = shirt.darkened(0.3)
    var f = int(clock * 10.0) % 4
    var bob = 0.0
    if mode == 'run' and (f == 1 or f == 3):
        bob = -u * 0.5
    if cape != null:
        var fl = sin(clock * 14.0) * u * 0.6 if mode != 'idle' else 0.0
        draw_rect(Rect2(-4.0 * u - u * 1.5 + fl, -14.0 * u + 4.0 * u + bob, u * 3.5, u * 6.0), cape)
    # legs
    if mode == 'jump':
        _b(2, 9, 2, 3, pants, bob); _b(2, 12, 3, 1, shoe, bob)
        _b(4, 9, 3, 2, pants, bob); _b(6, 11, 1, 1, shoe, bob)
    elif mode == 'run':
        if f == 0:
            _b(1, 9, 2, 4, pants); _b(0, 13, 3, 1, shoe)
            _b(4, 9, 2, 4, pants); _b(4, 13, 3, 1, shoe)
        elif f == 1:
            _b(2, 9, 2, 4, pants, bob); _b(2, 13, 2, 1, shoe, bob)
            _b(4, 9, 2, 3, pants, bob); _b(4, 12, 2, 1, shoe, bob)
        elif f == 2:
            _b(4, 9, 2, 4, pants); _b(4, 13, 3, 1, shoe)
            _b(1, 9, 2, 4, pants); _b(0, 13, 3, 1, shoe)
        else:
            _b(2, 9, 2, 3, pants, bob); _b(2, 12, 2, 1, shoe, bob)
            _b(4, 9, 2, 4, pants, bob); _b(4, 13, 3, 1, shoe, bob)
    else:
        _b(2, 9, 2, 4, pants); _b(2, 13, 2, 1, shoe)
        _b(4, 9, 2, 4, pants); _b(4, 13, 3, 1, shoe)
    # body + head
    _b(2, 4, 4, 5, shirt, bob)
    _b(2, 1, 4, 3, skin, bob)
    _b(2, 0, 4, 1, hair, bob)
    _b(2, 1, 1, 2, hair, bob)
    _b(5, 2, 1, 1, shoe, bob)
    # arms
    if mode == 'jump':
        _b(5, 4, 2, 1, shirt2, bob)
        _b(6, 2, 1, 3, skin, bob)
    elif mode == 'run' and (f == 0 or f == 2):
        _b(3, 5, 2, 3, shirt2, bob)
    else:
        _b(3, 5, 1, 4, shirt2, bob)
