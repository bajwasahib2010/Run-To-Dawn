extends Control
# Main menu: PLAY -> Difficulty -> Character select -> game.
# FREE PLAY = endless mode, the run only ends when you die. Also Leaderboard and Options (volume).

const UIKit = preload('res://Scripts/UIKit.gd')
const OptionsScript = preload('res://Scripts/Options.gd')
var t = 0.0
var options = null

func _ready():
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	GameData.free_play = false
	Audio.play_music('menu')
	add_child(UIKit.make_label('RUN TO DAWN', 104, UIKit.GOLD, Vector2(0, 30), 1280))
	add_child(UIKit.make_label('MAXIMUS LARPUS', 30, Color(0.9, 0.25, 0.2), Vector2(0, 160), 1280))

	var play = UIKit.make_button('PLAY', 32, Vector2(430, 225), Vector2(420, 62))
	play.pressed.connect(func():
		GameData.free_play = false
		get_tree().change_scene_to_file('res://Scenes/Difficulty.tscn'))
	add_child(play)
	var free_btn = UIKit.make_button('FREE PLAY  (endless)', 30, Vector2(430, 295), Vector2(420, 62), Color(0.55, 0.30, 0.15))
	free_btn.pressed.connect(func():
		GameData.free_play = true
		get_tree().change_scene_to_file('res://Scenes/Difficulty.tscn'))
	add_child(free_btn)
	var lb = UIKit.make_button('LEADERBOARD', 30, Vector2(430, 365), Vector2(420, 62))
	lb.pressed.connect(func(): get_tree().change_scene_to_file('res://Scenes/Leaderboard.tscn'))
	add_child(lb)
	var opt = UIKit.make_button('OPTIONS  (volume)', 30, Vector2(430, 435), Vector2(420, 62))
	opt.pressed.connect(func(): options.open())
	add_child(opt)
	var quit = UIKit.make_button('QUIT', 30, Vector2(430, 505), Vector2(420, 62))
	quit.pressed.connect(func(): get_tree().quit())
	add_child(quit)
	play.grab_focus()

	var info = 'Difficulty: %s     Characters unlocked: %d/%d     Levels cleared: %d/%d' % [
		GameData.difficulty, GameData.unlocked_count(), GameData.characters.size(),
		GameData.cleared_count(), GameData.levels.size()]
	add_child(UIKit.make_label(info, 20, UIKit.CREAM, Vector2(0, 596), 1280))
	add_child(UIKit.make_label('Free Play best distance: %d m' % int(GameData.free_best), 20, UIKit.GOLD, Vector2(0, 626), 1280))

	options = OptionsScript.new()
	options.on_close = func(): play.grab_focus()
	add_child(options)

func _process(delta):
	t += delta
	queue_redraw()

func _draw():
	UIKit.draw_night(self, t)
