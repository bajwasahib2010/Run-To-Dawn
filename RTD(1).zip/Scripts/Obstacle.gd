extends Area2D

# Used for both obstacles and bounce pads. Level.gd sets the fields
# below BEFORE adding it to the scene.
const Art = preload('res://Scripts/Art.gd')

var size = Vector2(50, 50)
var color = Color(0.5, 0.3, 0.1)
var sprite_name = 'crate'
var is_pad = false

func _ready():
    collision_layer = 0     # nothing collides WITH me
    collision_mask = 2      # but I detect layer 2 (the player)

    var shape = CollisionShape2D.new()
    var rect = RectangleShape2D.new()
    rect.size = size * Vector2(0.8, 0.9)    # slightly forgiving hitbox
    shape.shape = rect
    shape.position = Vector2(0, -size.y * 0.5)
    add_child(shape)

    add_child(Art.visual(sprite_name, size, color))
    body_entered.connect(_on_body_entered)

func _on_body_entered(body):
    if not body.is_in_group('player'):
        return
    if is_pad:
        body.bounce(900.0)
    else:
        body.stumble()
        set_deferred('monitoring', false)   # only hit once
        modulate = Color(1, 1, 1, 0.35)
