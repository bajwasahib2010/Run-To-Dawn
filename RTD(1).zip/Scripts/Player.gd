extends CharacterBody2D

const Art = preload('res://Scripts/Art.gd')
const RunnerScript = preload('res://Scripts/PixelRunner.gd')
const GRAVITY = 1800.0

var base_speed = 300.0
var jump_speed = 720.0
var char_speed = 300.0       # the character's own speed (no cheats)
var char_jump = 720.0
var runner = null            # code-drawn pixel runner (characters without a PNG)
var stumble_factor = 0.4

var active = false          # Level turns this on when the race starts
var stumble_timer = 0.0
var boost_timer = 0.0
var jump_buffer = 0.0
var coyote = 0.0
var sprite = null           # the animated pixel-art runner (if the PNG exists)
var step_timer = 0.0
var air_time = 0.0

func _ready():
    add_to_group('player')
    collision_layer = 2     # I am on layer 2
    collision_mask = 1      # I collide with layer 1 (the ground)

    var data = GameData.characters[GameData.selected_character]
    char_speed = data['speed']
    char_jump = data['jump']
    refresh_stats()
    stumble_factor = data['stumble']

    # hitbox: origin of this node is the FEET
    var shape = CollisionShape2D.new()
    var rect = RectangleShape2D.new()
    rect.size = Vector2(36, 70)
    shape.shape = rect
    shape.position = Vector2(0, -35)
    add_child(shape)

    # looks: animated pixel-art strip Sprites/elias_run.png (victor_run.png, lucian_run.png)
    # frames: 0-5 = run cycle, 6 = jump, 7 = standing
    sprite = Art.animated(GameData.selected_character.to_lower() + '_run', Vector2(24, 35),
            {'run': [0, 1, 2, 3, 4, 5], 'jump': [6], 'idle': [7]}, 2.0, 16.0)
    if sprite != null:
        sprite.play('idle')
        add_child(sprite)
    else:
        var look = Art.visual(GameData.selected_character.to_lower(), Vector2(36, 70), data['color'])
        if look is ColorRect:
            # no PNG for this character: draw a pixel runner in code instead
            look.free()
            runner = RunnerScript.new()
            runner.setup(data)
            add_child(runner)
        else:
            add_child(look)

    # camera sits ahead of the runner so you can see what's coming
    var cam = Camera2D.new()
    cam.position = Vector2(250, -150)
    cam.limit_left = 0
    add_child(cam)
    cam.make_current()

func _unhandled_input(event):
    var pressed = false
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_SPACE or event.keycode == KEY_UP or event.keycode == KEY_W:
            pressed = true
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        pressed = true
    elif event is InputEventScreenTouch and event.pressed:
        pressed = true
    if pressed:
        jump_buffer = 0.12

# applies the character's stats plus any cheats (the pause menu calls this)
func refresh_stats():
    base_speed = char_speed * GameData.speed_mult()
    jump_speed = char_jump * GameData.jump_mult()

func current_speed():
    if stumble_timer > 0.0:
        return base_speed * stumble_factor
    if boost_timer > 0.0:
        return base_speed * 1.35
    return base_speed

func _physics_process(delta):
    var was_stumbling = stumble_timer > 0.0
    stumble_timer = max(stumble_timer - delta, 0.0)
    if was_stumbling and stumble_timer <= 0.0 and active:
        Audio.sfx('recover', -2.0)      # you got back up: the "bounce back" chime
    boost_timer = max(boost_timer - delta, 0.0)
    jump_buffer = max(jump_buffer - delta, 0.0)

    if is_on_floor():
        coyote = 0.1
    else:
        coyote = max(coyote - delta, 0.0)
        velocity.y += GRAVITY * delta

    if active:
        velocity.x = current_speed()
        if jump_buffer > 0.0 and coyote > 0.0:
            velocity.y = -jump_speed
            jump_buffer = 0.0
            coyote = 0.0
            Audio.sfx('jump', -3.0, randf_range(0.95, 1.08))
    else:
        velocity.x = 0.0

    move_and_slide()
    _update_animation()
    _update_sounds(delta)

func _update_animation():
    if sprite == null:
        return
    if not active:
        _play('idle', 1.0)
    elif not is_on_floor():
        _play('jump', 1.0)
    else:
        # legs slow down when you stumble, speed up on a bounce boost
        _play('run', clamp(current_speed() / base_speed, 0.45, 1.5))

func _update_sounds(delta):
    if not active:
        return
    if is_on_floor():
        if air_time > 0.18:
            Audio.sfx('land', -6.0)
        air_time = 0.0
        step_timer -= delta
        if step_timer <= 0.0:
            Audio.sfx('step', -12.0, randf_range(0.85, 1.15))
            step_timer = 0.1875 / clamp(current_speed() / base_speed, 0.45, 1.5)
    else:
        air_time += delta

func _play(anim, speed):
    if sprite.animation != anim:
        sprite.play(anim)
    sprite.speed_scale = speed

# called by obstacles
func stumble():
    stumble_timer = 0.7
    boost_timer = 0.0
    Audio.sfx('hit')
    modulate = Color(1.0, 0.4, 0.4)
    var t = create_tween()
    t.tween_property(self, 'modulate', Color.WHITE, 0.7)
    # tell the level so it can take a heart and bounce us back
    var lvl = get_parent()
    if lvl != null and lvl.has_method('on_obstacle_hit'):
        lvl.on_obstacle_hit()

# called by bounce pads
func bounce(force):
    velocity.y = -force
    boost_timer = 0.8
    Audio.sfx('bounce')
    coyote = 0.0
