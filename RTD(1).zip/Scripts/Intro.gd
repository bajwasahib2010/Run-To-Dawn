extends Control
# 30-second intro film. All art is drawn in code, so no image files are needed.
# Any key / click / tap skips it. When it ends it loads next_scene.

@export var next_scene: String = "res://Scenes/MainMenu.tscn"

const W := 1280.0
const H := 720.0
const DURATION := 30.0
const BAR := 64.0
const GROUND := 560.0
const CUTS := [9.0, 19.5, 26.5, 28.0]
# [world x, width, height]
const HOUSES := [
	[-120.0, 220.0, 170.0], [200.0, 240.0, 150.0], [540.0, 220.0, 180.0],
	[860.0, 240.0, 160.0], [1500.0, 230.0, 175.0], [1820.0, 240.0, 155.0]
]
const TARGET_X := 1122.0   # the house with the light on (door ends at screen x 622)

var t := 0.0
var done := false
var stars: Array = []
var font: Font

# ---- audio (all synthesised in code, no sound files needed) ----
const RATE := 11025
var sfx := {}
var events: Array = []
var ev_i := 0
var ambient: AudioStreamPlayer
var arng := RandomNumberGenerator.new()


func _ready() -> void:
	font = ThemeDB.fallback_font
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	for i in 70:
		stars.append(Vector3(rng.randf() * W, rng.randf() * 360.0 + 40.0, rng.randf() * 6.0))
	_build_audio()
	_schedule()
	ambient = AudioStreamPlayer.new()
	ambient.stream = sfx["ambient"]
	ambient.volume_db = -14.0
	add_child(ambient)
	ambient.play()


func _process(delta: float) -> void:
	var dt = minf(delta, 0.1)   # building the sounds can cause one long first frame
	t += dt
	while ev_i < events.size() and events[ev_i][0] <= t:
		_play(events[ev_i][1], events[ev_i][2], events[ev_i][3])
		ev_i += 1
	var target = -14.0
	if t >= 29.4:
		target = -60.0
	elif t >= 26.5:
		target = -16.0
	elif t >= 19.5:
		target = -12.0
	elif t >= 9.0:
		target = -20.0
	ambient.volume_db = lerpf(ambient.volume_db, target, minf(dt * 3.0, 1.0))
	if t >= DURATION:
		_finish()
	queue_redraw()


func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		_finish()
	elif event is InputEventMouseButton and event.pressed:
		_finish()
	elif event is InputEventScreenTouch and event.pressed:
		_finish()


func _finish() -> void:
	if done:
		return
	done = true
	get_tree().change_scene_to_file("res://Scenes/MainMenu.tscn")


# ------------------------------------------------------------ helpers
func R(x, y, w, h, c) -> void:
	draw_rect(Rect2(x, y, w, h), c)


# one sprite "pixel block". gx,gy,gw,gh are in sprite units, u = screen px per unit,
# f = 1 faces right, -1 faces left, sw = sprite width in units (needed for flipping)
func S(ox, oy, u, f, sw, gx, gy, gw, gh, c) -> void:
	var x = ox + (gx if f == 1 else sw - gx - gw) * u
	draw_rect(Rect2(x, oy + gy * u, gw * u, gh * u), c)


func txt_at(s, x, y, size, col) -> void:
	draw_string(font, Vector2(x + 3, y + 3), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, Color(0, 0, 0, 0.85))
	draw_string(font, Vector2(x, y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


func txt_center(s, y, size, col) -> void:
	var w = font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	txt_at(s, (W - w) * 0.5, y, size, col)


# typewriter line, centred on its FULL width so it doesn't jitter
func type_line(s, start, y, size, col) -> void:
	var n = int((t - start) * 26.0)
	if n <= 0:
		return
	var w = font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	txt_at(s.substr(0, mini(n, s.length())), (W - w) * 0.5, y, size, col)


func cross(cx, cy, s, col) -> void:
	R(cx - s, cy - 4.0 * s, 2.0 * s, 8.0 * s, col)
	R(cx - 3.0 * s, cy - 2.0 * s, 6.0 * s, 2.0 * s, col)


func draw_stars(maxy) -> void:
	for s in stars:
		if s.y > maxy:
			continue
		var a = 0.35 + 0.5 * (0.5 + 0.5 * sin(t * 2.0 + s.z * 3.0))
		R(s.x, s.y, 4, 4, Color(1.0, 1.0, 0.9, a))


func moon(cx, cy) -> void:
	draw_circle(Vector2(cx, cy), 115.0, Color(0.7, 0.75, 1.0, 0.05))
	var u = 8.0
	for j in range(-7, 8):
		var hw = int(sqrt(maxf(49.0 - j * j, 0.0)) + 0.5)
		R(cx - hw * u, cy + j * u, hw * 2.0 * u, u, Color(0.93, 0.93, 0.8))
	R(cx - 24, cy - 24, 16, 16, Color(0.78, 0.78, 0.66))
	R(cx + 8, cy + 8, 24, 16, Color(0.78, 0.78, 0.66))
	R(cx - 8, cy + 24, 8, 8, Color(0.78, 0.78, 0.66))


# ------------------------------------------------------------ sprites
func hero(ox, feet_y, frame, f = 1, u = 5.0, arm_up = false) -> void:
	var sw = 8
	var oy = feet_y - 14.0 * u
	var skin = Color(0.93, 0.74, 0.58)
	var hair = Color(0.14, 0.09, 0.06)
	var shirt = Color(0.82, 0.18, 0.18)
	var shirt2 = Color(0.62, 0.12, 0.12)
	var pants = Color(0.14, 0.16, 0.32)
	var shoe = Color(0.06, 0.05, 0.05)
	if frame == 0:
		S(ox, oy, u, f, sw, 1, 9, 2, 4, pants); S(ox, oy, u, f, sw, 0, 13, 3, 1, shoe)
		S(ox, oy, u, f, sw, 4, 9, 2, 4, pants); S(ox, oy, u, f, sw, 4, 13, 3, 1, shoe)
	elif frame == 1:
		S(ox, oy, u, f, sw, 2, 9, 2, 3, pants); S(ox, oy, u, f, sw, 2, 12, 2, 1, shoe)
		S(ox, oy, u, f, sw, 4, 9, 2, 4, pants); S(ox, oy, u, f, sw, 4, 13, 3, 1, shoe)
	else:
		S(ox, oy, u, f, sw, 2, 9, 2, 4, pants); S(ox, oy, u, f, sw, 2, 13, 2, 1, shoe)
		S(ox, oy, u, f, sw, 4, 9, 2, 4, pants); S(ox, oy, u, f, sw, 4, 13, 3, 1, shoe)
	S(ox, oy, u, f, sw, 2, 4, 4, 5, shirt)
	S(ox, oy, u, f, sw, 2, 1, 4, 3, skin)
	S(ox, oy, u, f, sw, 2, 0, 4, 1, hair)
	S(ox, oy, u, f, sw, 2, 1, 1, 2, hair)
	S(ox, oy, u, f, sw, 5, 2, 1, 1, shoe)
	if arm_up:
		S(ox, oy, u, f, sw, 5, 4, 2, 1, shirt2)
		S(ox, oy, u, f, sw, 6, 2, 1, 3, skin)
	elif frame == 0:
		S(ox, oy, u, f, sw, 3, 5, 2, 3, shirt2)
	else:
		S(ox, oy, u, f, sw, 3, 5, 1, 4, shirt2)


func dog(ox, feet_y, f, u, wag) -> void:
	var sw = 10
	var oy = feet_y - 7.0 * u
	var fur = Color(0.66, 0.64, 0.62)
	var dark = Color(0.36, 0.34, 0.34)
	var blk = Color(0.05, 0.04, 0.04)
	S(ox, oy, u, f, sw, 0, 1 + wag, 1, 2, fur)
	S(ox, oy, u, f, sw, 1, 2, 6, 3, fur)
	S(ox, oy, u, f, sw, 7, 1, 3, 3, fur)
	S(ox, oy, u, f, sw, 7, 0, 1, 2, dark)
	S(ox, oy, u, f, sw, 9, 2, 1, 1, blk)
	S(ox, oy, u, f, sw, 8, 1, 1, 1, blk)
	for gx in [1, 3, 5, 6]:
		S(ox, oy, u, f, sw, gx, 5, 1, 2, dark)


func hellhound(ox, feet_y, u, f, frame, hurt = false, flame = 1.0) -> void:
	var sw = 18
	var oy = feet_y - 11.0 * u
	var body = Color(0.38, 0.04, 0.05)
	var dark = Color(0.2, 0.02, 0.04)
	var spike = Color(0.1, 0.01, 0.03)
	var glow = Color(1.0, 0.85, 0.2)
	if hurt:
		body = Color(0.97, 0.88, 0.8)
		dark = Color(0.85, 0.75, 0.68)
	var a = 0 if frame == 0 else 1
	# tail
	S(ox, oy, u, f, sw, 1, 3, 2, 1, dark)
	S(ox, oy, u, f, sw, 0, 2, 1, 1, dark)
	# legs
	S(ox, oy, u, f, sw, 3 + a, 7, 2, 4, dark)
	S(ox, oy, u, f, sw, 6 - a, 7, 2, 4, dark)
	S(ox, oy, u, f, sw, 10 + a, 7, 2, 4, dark)
	S(ox, oy, u, f, sw, 12 - a, 7, 2, 4, dark)
	# body, neck, head
	S(ox, oy, u, f, sw, 3, 3, 10, 4, body)
	S(ox, oy, u, f, sw, 4, 6, 8, 1, dark)
	S(ox, oy, u, f, sw, 12, 2, 2, 4, body)
	S(ox, oy, u, f, sw, 13, 1, 4, 4, body)
	S(ox, oy, u, f, sw, 16, 3, 2, 2, body)
	S(ox, oy, u, f, sw, 13, 0, 1, 2, dark)
	S(ox, oy, u, f, sw, 15, 0, 1, 1, dark)
	S(ox, oy, u, f, sw, 14, 5, 1, 1, Color(1, 1, 1))
	S(ox, oy, u, f, sw, 16, 5, 1, 1, Color(1, 1, 1))
	S(ox, oy, u, f, sw, 15, 2, 1, 1, glow)
	# back spikes + flames
	for gx in [4, 6, 8, 10]:
		S(ox, oy, u, f, sw, gx, 2, 1, 1, spike)
		var h = int(1.0 + 2.0 * flame * (0.5 + 0.5 * sin(t * 14.0 + gx * 2.0)))
		if flame > 0.05 and h > 0:
			S(ox, oy, u, f, sw, gx, 2 - h, 1, h, Color(1.0, 0.5, 0.08))
			S(ox, oy, u, f, sw, gx, 2 - h, 1, 1, Color(1.0, 0.85, 0.2))
	if flame > 0.05:
		S(ox, oy, u, f, sw, 0, 1, 1, 1, Color(1.0, 0.5, 0.08))


func house(x, by, w, h, body, roof, win, door, door_open = 0.0) -> void:
	R(x, by - h, w, h, body)
	for k in range(7):
		R(x - 14.0 + k * 14.0, by - h - (k + 1) * 14.0, w + 28.0 - 2.0 * k * 14.0, 14, roof)
	R(x + 30, by - h + 36, 36, 36, win)
	R(x + w - 66, by - h + 36, 36, 36, win)
	var dx = x + w * 0.5 - 20.0
	if door_open > 0.0:
		R(dx, by - 80, 40, 80, Color(1.0, 0.8, 0.4))
		R(dx, by - 80, 40.0 * (1.0 - door_open), 80, door)
		R(dx - 10, by, 60.0 + 70.0 * door_open, 8, Color(1.0, 0.8, 0.4, 0.25 * door_open))
	else:
		R(dx, by - 80, 40, 80, door)


func lamp(x) -> void:
	var f = 0.6 + 0.25 * sin(t * 13.0 + x * 0.1) + 0.15 * sin(t * 37.0 + x)
	if sin(t * 3.0 + x) > 0.96:
		f *= 0.3
	f = clampf(f, 0.15, 1.0)
	var post = Color(0.05, 0.05, 0.07)
	R(x - 4, GROUND - 150, 8, 160, post)
	R(x - 14, GROUND - 166, 28, 18, post)
	R(x - 8, GROUND - 162, 16, 10, Color(1.0, 0.85, 0.45, f))
	R(x - 36, GROUND - 190, 72, 72, Color(1.0, 0.8, 0.4, 0.04 * f))
	R(x - 60, GROUND - 214, 120, 120, Color(1.0, 0.8, 0.4, 0.03 * f))
	R(x - 70, GROUND, 140, 6, Color(1.0, 0.8, 0.4, 0.12 * f))


func vignette() -> void:
	for k in range(5):
		var a = 0.06 * (5 - k)
		R(0, 0, k * 22 + 22, H, Color(0, 0, 0, a))
		R(W - k * 22 - 22, 0, k * 22 + 22, H, Color(0, 0, 0, a))


# ------------------------------------------------------------ scenes
func backdrop(cam) -> void:
	R(0, 0, W, 300, Color(0.03, 0.04, 0.11))
	R(0, 300, W, 130, Color(0.05, 0.06, 0.16))
	R(0, 430, W, 130, Color(0.08, 0.08, 0.2))
	draw_stars(420.0)
	moon(1020.0, 150.0)
	var c = Color(0.05, 0.06, 0.15)
	var c2 = Color(0.04, 0.05, 0.12)
	for i in range(-1, 8):
		var k = int(floor(cam * 0.4 / 260.0)) + i
		var hh = 80.0 + posmod(k * 37, 5) * 14.0
		house(k * 260.0 - cam * 0.4, GROUND - 6.0, 200.0, hh, c, c2, c, c)
	R(0, GROUND, W, H - GROUND, Color(0.10, 0.09, 0.13))
	R(0, GROUND, W, 6, Color(0.2, 0.19, 0.26))
	for i in range(0, 14):
		R(i * 110.0 - fposmod(cam, 110.0), GROUND + 50, 50, 6, Color(0.17, 0.16, 0.22))


func fog() -> void:
	for i in range(3):
		var x = fposmod(t * 20.0 + i * 500.0, 1500.0) - 220.0
		R(x, GROUND - 30.0 + i * 16.0, 420, 30, Color(0.6, 0.65, 0.8, 0.05))


func scene_town() -> void:
	var cam = minf(t * 100.0, 620.0)
	backdrop(cam)
	for hd in HOUSES:
		var sx = hd[0] - cam
		if sx > -320.0 and sx < 1300.0:
			house(sx, GROUND, hd[1], hd[2], Color(0.08, 0.09, 0.22), Color(0.06, 0.06, 0.16),
				Color(0.03, 0.04, 0.09), Color(0.05, 0.05, 0.1))
	var open = clampf((t - 8.3) / 0.6, 0.0, 1.0)
	house(TARGET_X - cam, GROUND, 240.0, 175.0, Color(0.10, 0.10, 0.25), Color(0.07, 0.07, 0.18),
		Color(1.0, 0.75, 0.3), Color(0.2, 0.12, 0.07), open)
	for lx in [490.0, 810.0, 1430.0]:
		lamp(lx - cam)
	var hx = 380.0
	if t > 6.2:
		hx = 380.0 + minf((t - 6.2) * 110.0, 242.0)
	var walking = t < 8.4
	var fr = (int(t * 7.0) % 2) if walking else 2
	hero(hx, GROUND + 34.0, fr, 1, 5.0, false)
	fog()


func scene_inside() -> void:
	var feet = GROUND + 30.0
	var shake = Vector2.ZERO
	if t > 16.2 and t < 19.0:
		shake = Vector2(sin(t * 91.0), cos(t * 77.0)) * 6.0 * (1.0 - (t - 16.2) / 2.8)
	draw_set_transform(shake, 0.0, Vector2.ONE)

	# room
	R(-20, -20, W + 40, H + 40, Color(0.10, 0.065, 0.06))
	for i in range(0, 14):
		R(i * 96.0, 0, 4, GROUND, Color(0, 0, 0, 0.25))
	R(-20, GROUND, W + 40, 200, Color(0.19, 0.11, 0.07))
	for i in range(0, 9):
		R(-20, GROUND + i * 22.0, W + 40, 3, Color(0, 0, 0, 0.3))
	R(-20, GROUND - 14, W + 40, 14, Color(0.07, 0.04, 0.03))
	# door (open, light outside)
	R(34, GROUND - 198, 8, 198, Color(0.07, 0.04, 0.03))
	R(42, GROUND - 190, 108, 190, Color(0.22, 0.27, 0.5))
	R(42, GROUND - 190, 22, 190, Color(0.3, 0.18, 0.1))
	draw_colored_polygon(PackedVector2Array([Vector2(42, GROUND), Vector2(150, GROUND),
		Vector2(330, GROUND + 90), Vector2(42, GROUND + 90)]), Color(0.45, 0.55, 1.0, 0.08))
	# window + moonlight
	R(880, 170, 150, 190, Color(0.28, 0.17, 0.09))
	R(892, 182, 126, 166, Color(0.2, 0.25, 0.5))
	R(950, 182, 6, 166, Color(0.28, 0.17, 0.09))
	R(892, 260, 126, 6, Color(0.28, 0.17, 0.09))
	draw_colored_polygon(PackedVector2Array([Vector2(892, 348), Vector2(1018, 348),
		Vector2(1120, GROUND + 90), Vector2(780, GROUND + 90)]), Color(0.5, 0.6, 1.0, 0.06))
	# bookshelf
	R(1080, 250, 150, 310, Color(0.15, 0.09, 0.05))
	for i in range(0, 4):
		R(1086, 270 + i * 70.0, 138, 6, Color(0.08, 0.05, 0.03))
		for j in range(0, 6):
			R(1092 + j * 22.0, 232 + i * 70.0 + (j % 2) * 6.0, 14, 38 - (j % 2) * 6.0,
				Color(0.35 + 0.1 * (j % 3), 0.12, 0.1 + 0.08 * (i % 2)))
	# table + candle
	R(470, GROUND - 60, 130, 12, Color(0.25, 0.14, 0.08))
	R(480, GROUND - 48, 10, 48, Color(0.2, 0.11, 0.06))
	R(580, GROUND - 48, 10, 48, Color(0.2, 0.11, 0.06))
	R(530, GROUND - 92, 10, 32, Color(0.9, 0.85, 0.7))
	var fl = 10.0 + 5.0 * sin(t * 17.0)
	R(532, GROUND - 92 - fl, 6, fl, Color(1.0, 0.65, 0.15))
	draw_circle(Vector2(535, GROUND - 100), 70.0, Color(1.0, 0.7, 0.3, 0.07))
	draw_circle(Vector2(535, GROUND - 100), 130.0, Color(1.0, 0.7, 0.3, 0.04))

	# hero
	var hx = 150.0 + clampf((t - 9.5) / 3.0, 0.0, 1.0) * 210.0
	var walking = t > 9.5 and t < 12.5
	if t > 16.2:
		hx = 360.0 - clampf((t - 16.2) / 1.5, 0.0, 1.0) * 70.0
	var fr = (int(t * 7.0) % 2) if walking else 2
	hero(hx, feet, fr, 1, 5.0, false)

	# dog -> hellhound
	if t < 16.2:
		var face = 1 if t < 14.9 else -1
		var shk = Vector2.ZERO
		if t > 15.4:
			shk = Vector2(sin(t * 80.0), cos(t * 65.0)) * (t - 15.4) * 3.0
		var du = 5.0 + clampf((t - 15.4) / 0.8, 0.0, 1.0)
		dog(820.0 + shk.x, feet + shk.y, face, du, int(t * 3.0) % 2)
	else:
		var k = clampf((t - 16.2) / 2.5, 0.0, 1.0)
		var bob = sin(t * 6.0) * 3.0
		hellhound(690.0, feet + bob, lerpf(6.0, 10.0, k), -1, 0, false, 1.0)
		R(-20, -20, W + 40, H + 40, Color(0.6, 0.0, 0.0, 0.12 + 0.06 * sin(t * 10.0)))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func chapel(x) -> void:
	var wall = Color(0.17, 0.17, 0.26)
	var roof = Color(0.11, 0.11, 0.2)
	var gold = Color(1.0, 0.9, 0.45)
	for r in [60.0, 120.0, 190.0]:
		draw_circle(Vector2(x + 120.0, GROUND - 340.0), r, Color(1.0, 0.9, 0.5, 0.05))
	R(x, GROUND - 170, 240, 170, wall)
	for k in range(7):
		R(x - 14.0 + k * 14.0, GROUND - 170.0 - (k + 1) * 14.0, 268.0 - 28.0 * k, 14, roof)
	R(x + 90, GROUND - 300, 60, 130, wall)
	R(x + 82, GROUND - 312, 76, 14, roof)
	R(x + 108, GROUND - 270, 24, 36, gold)
	cross(x + 120.0, GROUND - 342.0, 5.0, gold)
	R(x + 95, GROUND - 90, 50, 90, gold)
	R(x + 105, GROUND - 80, 30, 80, Color(1.0, 1.0, 0.8))
	R(x + 22, GROUND - 130, 30, 50, gold)
	R(x + 188, GROUND - 130, 30, 50, gold)


func scene_holy() -> void:
	var lt = t - 19.5
	var k = clampf((lt - 0.4) / 1.6, 0.0, 1.0)
	var feet = GROUND + 30.0
	R(0, 0, W, H, Color(0.02, 0.02, 0.07))
	R(0, 300, W, 260, Color(0.04, 0.04, 0.12))
	draw_stars(400.0)
	R(0, GROUND, W, H - GROUND, Color(0.06, 0.06, 0.1))
	R(0, GROUND, W, 5, Color(0.14, 0.14, 0.22))
	chapel(80.0)

	# hero holding a holy cross
	hero(480.0, feet, 2, 1, 5.0, true)
	var cx = 480.0 + 6.5 * 5.0
	var cy = feet - 76.0
	var pulse = 0.85 + 0.15 * sin(t * 18.0)
	for r in [50.0, 100.0, 160.0, 230.0]:
		draw_circle(Vector2(cx, cy), r, Color(1.0, 0.9, 0.5, 0.09 * k * pulse))
	cross(cx, cy, 4.0, Color(1.0, 0.9, 0.4))

	# hellhound recoils
	var hx = 960.0 + clampf(lt / 3.0, 0.0, 1.0) * 100.0
	if k > 0.0:
		draw_colored_polygon(PackedVector2Array([Vector2(cx, cy), Vector2(hx, feet - 120.0),
			Vector2(hx, feet)]), Color(1.0, 0.9, 0.5, 0.14 * k * pulse))
	var hurt = k > 0.5 and int(t * 12.0) % 2 == 0
	hellhound(hx + sin(t * 40.0) * 4.0 * k, feet, 8.0, -1, 0, hurt, 1.0 - k)
	if k > 0.6:
		for i in range(6):
			var sy = fposmod(t * 60.0 + i * 40.0, 170.0)
			R(hx + 20.0 + i * 20.0, feet - 100.0 - sy, 10, 10, Color(0.65, 0.65, 0.7, 0.3 * (1.0 - sy / 170.0)))

	type_line("HELLHOUNDS ARE WEAK TO THE HOLY.", 19.9, 150, 34, Color(1.0, 1.0, 1.0))
	type_line("SACRED OBJECTS BURN THEM.", 22.0, 200, 34, Color(1.0, 0.9, 0.4))
	type_line("HOLY PLACES ARE THEIR CAGE.", 24.0, 250, 34, Color(1.0, 0.9, 0.4))


func scene_chase() -> void:
	var lt = t - 26.5
	var cam = 600.0 + lt * 350.0
	backdrop(cam)
	for i in range(0, 5):
		lamp(fposmod(i * 420.0 - cam, 2100.0) - 100.0)
	hero(780.0, GROUND + 34.0, int(t * 12.0) % 2, 1, 6.0, false)
	var lift = 0.0
	if lt > 1.0:
		lift = 80.0 * sin(clampf((lt - 1.0) / 0.5, 0.0, 1.0) * PI)
	hellhound(-330.0 + lt * 560.0, GROUND + 34.0 - lift, 9.0, 1, int(t * 14.0) % 2, false, 1.0)
	fog()
	R(0, 0, W, H, Color(0.5, 0.0, 0.0, 0.10 + 0.05 * sin(t * 12.0)))


func scene_title() -> void:
	var lt = t - 28.0
	R(0, 0, W, H, Color(0.02, 0.0, 0.04))
	for i in range(14):
		var ang = i * TAU / 14.0 + t * 0.15
		var c = Vector2(640, 340)
		draw_colored_polygon(PackedVector2Array([c, c + Vector2(cos(ang - 0.06), sin(ang - 0.06)) * 900.0,
			c + Vector2(cos(ang + 0.06), sin(ang + 0.06)) * 900.0]), Color(0.9, 0.15, 0.1, 0.10))
	var s = 1.0 + maxf(0.0, 0.6 - lt * 2.0)
	draw_set_transform(Vector2(640, 340) * (1.0 - s), 0.0, Vector2(s, s))
	var lines = ["MAXIMUS", "LARPUS"]
	for li in range(2):
		var y = 290.0 + li * 150.0
		var w = font.get_string_size(lines[li], HORIZONTAL_ALIGNMENT_LEFT, -1, 150).x
		var x = (W - w) * 0.5
		for off in [Vector2(12, 12), Vector2(8, 8)]:
			draw_string(font, Vector2(x, y) + off, lines[li], HORIZONTAL_ALIGNMENT_LEFT, -1, 150, Color(0.5, 0.03, 0.03))
		for off in [Vector2(-4, 0), Vector2(4, 0), Vector2(0, -4), Vector2(0, 4)]:
			draw_string(font, Vector2(x, y) + off, lines[li], HORIZONTAL_ALIGNMENT_LEFT, -1, 150, Color(0, 0, 0))
		draw_string(font, Vector2(x, y), lines[li], HORIZONTAL_ALIGNMENT_LEFT, -1, 150, Color(1.0, 0.82, 0.25))
		draw_string(font, Vector2(x - 2, y - 3), lines[li], HORIZONTAL_ALIGNMENT_LEFT, -1, 150, Color(1.0, 1.0, 0.8, 0.35))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func subtitles() -> void:
	var s = ""
	if t > 0.8 and t < 4.4:
		s = "Night falls over the village."
	elif t > 4.6 and t < 8.8:
		s = "One house still has its light on."
	elif t > 9.5 and t < 14.0:
		s = "Inside, a dog waits. Alone."
	elif t > 14.8 and t < 19.2:
		s = "That is no dog."
	elif t > 26.8 and t < 28.0:
		s = "RUN."
	if s != "":
		txt_center(s, H - BAR * 0.5 + 9.0, 26, Color(1, 1, 1))


# ------------------------------------------------------------ audio
func _play(sname: String, vol := 0.0, pitch := 1.0) -> void:
	var p := AudioStreamPlayer.new()
	p.stream = sfx[sname]
	p.volume_db = vol
	p.pitch_scale = pitch
	add_child(p)
	p.finished.connect(p.queue_free)
	p.play()


func _schedule() -> void:
	var tt = 0.3
	while tt < 8.4:
		events.append([tt, "step", -10.0, 1.0])
		tt += 0.286
	events.append([8.3, "creak", -4.0, 1.0])
	tt = 9.9
	while tt < 12.5:
		events.append([tt, "step", -9.0, 0.9])
		tt += 0.286
	events.append([14.9, "whine", -6.0, 1.0])
	events.append([15.4, "growl", -8.0, 1.2])
	events.append([16.05, "impact", 0.0, 1.0])
	events.append([16.2, "roar", 0.0, 1.0])
	events.append([19.9, "chime", -6.0, 1.0])
	events.append([20.2, "pad", -8.0, 1.0])
	events.append([21.0, "sizzle", -6.0, 1.0])
	events.append([21.1, "yelp", -4.0, 1.0])
	events.append([22.0, "chime", -8.0, 1.25])
	events.append([24.0, "chime", -8.0, 1.5])
	events.append([26.5, "roar", -2.0, 0.9])
	tt = 26.5
	while tt < 28.0:
		events.append([tt, "drum", -2.0, 1.0])
		events.append([tt + 0.08, "step", -6.0, 1.3])
		tt += 0.25
	events.append([28.0, "boom", 0.0, 1.0])
	events.sort_custom(func(a, b): return a[0] < b[0])


func _wav(data: PackedFloat32Array, loop := false) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(data.size() * 2)
	for i in data.size():
		bytes.encode_s16(i * 2, int(clampf(data[i], -1.0, 1.0) * 32767.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = data.size()
	return w


func _buf(sec: float) -> PackedFloat32Array:
	var a := PackedFloat32Array()
	a.resize(int(sec * RATE))
	return a


func _build_audio() -> void:
	arng.seed = 99
	var a: PackedFloat32Array
	var ph = 0.0
	var lp = 0.0
	var tt = 0.0

	# ambience: low drone + wind. 4 s, loops cleanly
	a = _buf(4.0)
	lp = 0.0
	for i in a.size():
		tt = float(i) / RATE
		var env = sin(PI * float(i) / a.size())
		lp += (arng.randf() * 2.0 - 1.0 - lp) * 0.05
		var trem = 0.75 + 0.25 * sin(TAU * 0.5 * tt)
		a[i] = ((sin(TAU * 55.0 * tt) * 0.35 + sin(TAU * 82.5 * tt) * 0.2 + sin(TAU * 110.0 * tt) * 0.08) * trem + lp * 2.5 * env * env) * 0.6
	sfx["ambient"] = _wav(a, true)

	# footstep
	a = _buf(0.14)
	lp = 0.0
	for i in a.size():
		tt = float(i) / RATE
		lp += (arng.randf() * 2.0 - 1.0 - lp) * 0.3
		a[i] = (sin(TAU * 95.0 * tt) * 0.7 + lp * 0.6) * exp(-tt * 35.0)
	sfx["step"] = _wav(a)

	# door creak
	a = _buf(1.1)
	ph = 0.0
	for i in a.size():
		tt = float(i) / RATE
		ph += TAU * (160.0 + 90.0 * sin(PI * tt / 1.1) + 8.0 * sin(TAU * 28.0 * tt)) / RATE
		var env = sqrt(maxf(sin(PI * tt / 1.1), 0.0)) * (0.7 + 0.3 * sin(TAU * 17.0 * tt))
		a[i] = (sin(ph) + 0.5 * sin(2.0 * ph) + 0.3 * sin(3.0 * ph)) * 0.22 * env
	sfx["creak"] = _wav(a)

	# dog whine
	a = _buf(0.9)
	ph = 0.0
	for i in a.size():
		tt = float(i) / RATE
		ph += TAU * (520.0 - 140.0 * tt / 0.9 + 12.0 * sin(TAU * 6.0 * tt)) / RATE
		a[i] = sin(ph) * 0.3 * sin(PI * tt / 0.9)
	sfx["whine"] = _wav(a)

	# low growl
	var dur = 1.6
	a = _buf(dur)
	ph = 0.0
	lp = 0.0
	for i in a.size():
		tt = float(i) / RATE
		ph += TAU * (62.0 + 6.0 * sin(TAU * 3.0 * tt)) / RATE
		lp += (arng.randf() * 2.0 - 1.0 - lp) * 0.15
		var am = 0.6 + 0.4 * sin(TAU * 26.0 * tt)
		var env = clampf(tt * 10.0, 0.0, 1.0) * clampf((dur - tt) * 4.0, 0.0, 1.0)
		a[i] = (fposmod(ph / TAU, 1.0) * 0.8 - 0.4) * am * env + lp * 0.5 * env
	sfx["growl"] = _wav(a)

	# big hellhound roar
	dur = 2.4
	a = _buf(dur)
	ph = 0.0
	lp = 0.0
	for i in a.size():
		tt = float(i) / RATE
		ph += TAU * (55.0 + 90.0 * tt / dur + 10.0 * sin(TAU * 5.0 * tt)) / RATE
		lp += (arng.randf() * 2.0 - 1.0 - lp) * 0.25
		var saw = fposmod(ph / TAU, 1.0) * 2.0 - 1.0
		var am = 0.7 + 0.3 * sin(TAU * 32.0 * tt)
		var env = clampf(tt * 20.0, 0.0, 1.0) * clampf((dur - tt) * 2.0, 0.0, 1.0)
		a[i] = (clampf(saw * 2.5, -1.0, 1.0) * 0.3 * am + lp * 0.45 + sin(ph * 0.5) * 0.3) * env
	sfx["roar"] = _wav(a)

	# transformation impact
	a = _buf(1.2)
	ph = 0.0
	for i in a.size():
		tt = float(i) / RATE
		ph += TAU * (35.0 + 55.0 * exp(-tt * 8.0)) / RATE
		a[i] = sin(ph) * exp(-tt * 4.0) * 0.9 + (arng.randf() * 2.0 - 1.0) * exp(-tt * 25.0) * 0.7
	sfx["impact"] = _wav(a)

	# holy bell chime
	a = _buf(3.0)
	var fr = [523.25, 659.25, 783.99, 1046.5]
	for i in a.size():
		tt = float(i) / RATE
		var v = 0.0
		for j in range(4):
			v += sin(TAU * fr[j] * tt) * exp(-tt * (1.2 + j * 0.5)) * 0.2
			v += sin(TAU * fr[j] * 2.01 * tt) * exp(-tt * 3.0) * 0.04
		a[i] = v * minf(tt * 200.0, 1.0)
	sfx["chime"] = _wav(a)

	# swelling holy pad
	a = _buf(4.0)
	for i in a.size():
		tt = float(i) / RATE
		var env = pow(sin(PI * tt / 4.0), 2.0)
		a[i] = (sin(TAU * 261.6 * tt + 0.5 * sin(TAU * 5.0 * tt)) + sin(TAU * 392.0 * tt) + 0.7 * sin(TAU * 523.3 * tt)) * 0.1 * env
	sfx["pad"] = _wav(a)

	# burning sizzle
	a = _buf(2.0)
	lp = 0.0
	for i in a.size():
		tt = float(i) / RATE
		var nz = arng.randf() * 2.0 - 1.0
		lp += (nz - lp) * 0.3
		var spike = 0.0
		if arng.randf() < 0.02:
			spike = (arng.randf() * 2.0 - 1.0) * 0.8
		a[i] = ((nz - lp) * 0.2 * (0.6 + 0.4 * sin(TAU * 35.0 * tt)) + spike * 0.3) * sin(PI * tt / 2.0)
	sfx["sizzle"] = _wav(a)

	# pained yelp
	a = _buf(0.6)
	ph = 0.0
	for i in a.size():
		tt = float(i) / RATE
		ph += TAU * (300.0 + 600.0 * exp(-tt * 5.0)) / RATE
		a[i] = (sin(ph) * 0.35 + fposmod(ph / TAU, 1.0) * 0.1) * exp(-tt * 3.0) * minf(tt * 100.0, 1.0)
	sfx["yelp"] = _wav(a)

	# chase drum
	a = _buf(0.3)
	ph = 0.0
	for i in a.size():
		tt = float(i) / RATE
		ph += TAU * (45.0 + 90.0 * exp(-tt * 25.0)) / RATE
		a[i] = sin(ph) * exp(-tt * 9.0) * 0.9
	sfx["drum"] = _wav(a)

	# title boom
	a = _buf(3.0)
	for i in a.size():
		tt = float(i) / RATE
		a[i] = sin(TAU * 50.0 * tt) * exp(-tt * 1.5) * 0.7 + sin(TAU * 73.0 * tt) * exp(-tt * 2.0) * 0.3 \
			+ (arng.randf() * 2.0 - 1.0) * exp(-tt * 10.0) * 0.6 \
			+ sin(TAU * 440.0 * tt) * exp(-tt * 3.0) * 0.08 + sin(TAU * 660.7 * tt) * exp(-tt * 3.5) * 0.06
	sfx["boom"] = _wav(a)


# ------------------------------------------------------------ main draw
func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if t < 9.0:
		scene_town()
	elif t < 19.5:
		scene_inside()
	elif t < 26.5:
		scene_holy()
	elif t < 28.0:
		scene_chase()
	else:
		scene_title()
	vignette()
	# cinematic bars
	R(0, 0, W, BAR, Color(0, 0, 0))
	R(0, H - BAR, W, BAR, Color(0, 0, 0))
	subtitles()
	if t < 28.0:
		txt_at("PRESS ANY KEY TO SKIP", W - 250.0, 40.0, 16, Color(1, 1, 1, 0.45))
	# flash when the dog transforms
	var fa = clampf(1.0 - absf(t - 16.25) / 0.25, 0.0, 1.0)
	if fa > 0.0:
		R(0, 0, W, H, Color(1, 1, 1, fa))
	# fade to black at the cuts, at the start and at the very end
	var a = clampf(1.0 - t / 0.7, 0.0, 1.0)
	for c in CUTS:
		a = maxf(a, 1.0 - absf(t - c) / 0.3)
	a = maxf(a, (t - 29.5) / 0.5)
	if a > 0.0:
		R(0, 0, W, H, Color(0, 0, 0, clampf(a, 0.0, 1.0)))
