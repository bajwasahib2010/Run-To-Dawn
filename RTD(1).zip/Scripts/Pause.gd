extends CanvasLayer
# Pause menu with cheats. Level creates it and calls open().
# Esc / P closes it again.

const UIKit = preload('res://Scripts/UIKit.gd')
const OptionsScript = preload('res://Scripts/Options.gd')

var level = null
var options = null
var resume_btn
var cheat_btns = {}

func _init():
    layer = 50
    process_mode = Node.PROCESS_MODE_ALWAYS     # keep working while the game is paused

func _ready():
    visible = false
    var dim = ColorRect.new()
    dim.color = Color(0, 0, 0, 0.72)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(dim)
    add_child(UIKit.make_label('PAUSED', 72, UIKit.GOLD, Vector2(0, 30), 1280))

    resume_btn = UIKit.make_button('RESUME', 30, Vector2(380, 140), Vector2(250, 60))
    resume_btn.pressed.connect(close)
    add_child(resume_btn)
    var opt_btn = UIKit.make_button('OPTIONS', 30, Vector2(650, 140), Vector2(250, 60))
    opt_btn.pressed.connect(func(): options.open())
    add_child(opt_btn)

    add_child(UIKit.make_label('CHEATS', 30, UIKit.RED, Vector2(0, 220), 1280))
    add_child(UIKit.make_label('runs with cheats are not saved to the leaderboard', 18, UIKit.CREAM, Vector2(0, 258), 1280))
    var y = 300.0
    for key in ['god', 'speed', 'jump']:
        var b = UIKit.make_button('', 26, Vector2(380, y), Vector2(520, 56))
        b.pressed.connect(_toggle.bind(key))
        add_child(b)
        cheat_btns[key] = b
        y += 66.0
    _refresh_cheats()

    var restart = UIKit.make_button('RESTART LEVEL', 28, Vector2(380, 510), Vector2(520, 56))
    restart.pressed.connect(func():
        get_tree().paused = false
        get_tree().reload_current_scene())
    add_child(restart)
    var quit = UIKit.make_button('QUIT TO MENU', 28, Vector2(380, 576), Vector2(520, 56))
    quit.pressed.connect(func():
        get_tree().paused = false
        get_tree().change_scene_to_file('res://Scenes/MainMenu.tscn'))
    add_child(quit)
    options = OptionsScript.new()
    options.on_close = func(): resume_btn.grab_focus()
    add_child(options)

func _on_off(v):
    return 'ON' if v else 'OFF'

func _refresh_cheats():
    cheat_btns['god'].text = 'UNLIMITED HEALTH:  ' + _on_off(GameData.cheat_god)
    cheat_btns['speed'].text = 'SPEED BOOST:  ' + _on_off(GameData.cheat_speed)
    cheat_btns['jump'].text = 'JUMP BOOST:  ' + _on_off(GameData.cheat_jump)

func _toggle(key):
    if key == 'god':
        GameData.cheat_god = not GameData.cheat_god
    elif key == 'speed':
        GameData.cheat_speed = not GameData.cheat_speed
    else:
        GameData.cheat_jump = not GameData.cheat_jump
    _refresh_cheats()
    if level != null:
        level.on_cheats_changed()

func open():
    visible = true
    get_tree().paused = true
    resume_btn.grab_focus()

func close():
    visible = false
    get_viewport().gui_release_focus()
    get_tree().paused = false

func _input(event):
    if visible and not (options != null and options.visible) and event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE or event.keycode == KEY_P:
            close()
            get_viewport().set_input_as_handled()
